#ifndef FUNC_H /* ����� */
#define FUNC_H /* �������������� ��������� - ������ */

void Line(int, char);

void RectPS(double,double,double,double,double&,double&);
double genRand(double min = -100., double max = 100.);
int genRand(int min = -10000, int max = 10000);


void IncTime(int&,int&,int&,int);
void displayTime(int,int,int);

void genArray(int N, int A[], int = -6, int = 19);
//void funcA(int N, int A[]);
void funcB(int N, int A[], int X = 0);
void funcC(int N, int A[], int Div = 1);
void funcD(int N, int A[], int Mult = 1);


//Specialized templates can be implemented in an implementation file
//and the implementation doesn't have to be visible,
//but the specialization must be previously declared.


template <typename T>
void display(int N,const T* A,string message = "������: ", int norm=10, int setwN=6) {
	cout << endl << "\t" << message << endl;
	int cnt = 0;
	for (int i = 0; i < N; i++) {
		cout << setw(setwN) << A[i] << " ";
		cnt++;
		if (cnt % norm == 0) cout << endl;
	}
	cout << endl;
}

#endif //FUNC_H
