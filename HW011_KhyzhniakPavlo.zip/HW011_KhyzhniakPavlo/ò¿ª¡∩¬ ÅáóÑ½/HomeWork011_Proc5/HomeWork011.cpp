﻿
#include "pch.h"
#include "Utils.h"
#include "Func.h"
#include "Application.h"

HANDLE hStdout;
CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
WORD wOldColorAttrs;


int main()
{
	init();

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - на 01.09.2019год.");

	//**************************************************************************

	srand(GetTickCount64());

	try {
		//test2();
		test();
	}
	catch (exception ex) {  // обработка исключения
		SetConsoleTextAttribute(hStdout, FOREGROUND_BLUE | BACKGROUND_RED | FOREGROUND_INTENSITY);
		cout << "\n\n"
			<< "\t\t                                                       \n"
			<< "\t\t    [Ошибка]                                           \n"
			<< "\t\t    " << left << setw(48) << ex.what() << right << "   \n"
			<< "\t\t                                                       \n"
			<< "\n\n\n\n\n\n\n\n\n\n\n\n";
		SetConsoleTextAttribute(hStdout, FOREGROUND_RED | FOREGROUND_INTENSITY);
		Pause();
	}
	//**************************************************************************


	SetConsoleTextAttribute(hStdout, FOREGROUND_BLUE | BACKGROUND_RED | FOREGROUND_INTENSITY);
	cout << "\n\n"
		<< "\t                                                       \n"
		<< "\t    [К сведению]                                       \n"
		<< "\t    Конец работы приложения                            \n"
		<< "\t                                                       \n"
		<< "\n\n\n\n\n\n\n\n\n\n\n\n\n";
	SetConsoleTextAttribute(hStdout, FOREGROUND_RED | FOREGROUND_INTENSITY);
	Pause();
	
	// Restore the original text colors. 
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);

	WINCLEAR;
	return 0;

}

