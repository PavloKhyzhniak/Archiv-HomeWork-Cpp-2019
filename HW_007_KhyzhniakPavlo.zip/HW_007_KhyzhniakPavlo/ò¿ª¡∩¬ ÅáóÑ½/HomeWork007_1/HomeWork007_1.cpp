﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 14.07.2019год.");

	//**************************************************************************
#pragma region Part01
	//Определение необходимых переменных
	int n, g, m;

	while (true)
	{
#pragma region Copyright
		WINCLEAR;
		cout << "\n\n\n\n\n\n\n";
		cout << "                                  ___________________                        " << endl
			<< "                                 / _________________ \\                      " << endl
			<< "                                / /                 \\_|                     " << endl
			<< "               __________      / /                                           " << endl
			<< "              |_________ \\    / /                                           " << endl
			<< "                        | \\  / /                                            " << endl
			<< "                        |  \\/ /                                             " << endl
			<< "                        |    /                                               " << endl
			<< "                        |   /                                                " << endl
			<< "                        |  /                                                 " << endl
			<< "                        | /                                                  " << endl
			<< "                        |/                                                   " << endl;
		cout << "\n\n\n\n\n\n\n";
		cout << "\t\t\t\t© Pavlo Khyzhniak, 2019. При копировании материала ссылка на источник обязательна." << endl;
		//Sleep(1000);
#pragma endregion

		WINCLEAR;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		_LineStar100_

		cout << "\t\t\t\t" << " О П Е Р А Т О Р   В Ы Б О Р А  " << endl;

		_LineStar100_

			cout << "\t\tЗадача 1. Дата некоторого дня характеризуется тремя натуральными числами:" << endl
			<< "\tg (год), m (порядковый номер месяца) и n (число). По заданным g, m, n определить:" << endl
			<< "\t - дату предыдущего дня;" << endl
			<< "\t - дату следующего дня." << endl;

#pragma region INPUT
		//Ввод входных данных
		_LineStar100_
					
		bool keyLoop;
		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите целое число для года: ";
			//проверим правильность считываемых данных
			if (!(cin >> g)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				if (g >= 1) 
					break;
			}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы ввели целое число g = " << g << endl;

		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите целое число для месяца: ";
			//проверим правильность считываемых данных
			if (!(cin >> m)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				if ((m >= 1) && (m<=12))
					break;
			}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы ввели целое число m = " << m << endl;

		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите целое число для дня: ";
			//проверим правильность считываемых данных
			if (!(cin >> n)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				switch (m) {
				case 1: case 3: case 5: case 7: case 8: case 10: case 12: keyLoop = ((n >= 1) && (n <= 31)); break;
				case 4: case 6: case 9: case 11: keyLoop = ((n >= 1) && (n <= 30)); break;
				case 2: keyLoop = (((g % 4 == 0) && (g % 100 != 0)) || (g % 400 == 0)) ? ((n >= 1) && (n <= 29)) : ((n >= 1) && (n <= 28)); break;
				default:
					cout << "\n\tЗначение месяца введено не корректно. Повторите ввод.\r";
					Sleep(1000);
					cout << "\t                                                       \r";
					continue;
				}
				if (!keyLoop) {
					cout << "\n\tЗначение дня не соответствует месяцу. Повторите ввод.\r";
					Sleep(1000);
					cout << "\t                                                       \r";
					keyLoop = true;
					continue;
				}
				break; 
				}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			keyLoop = true;
			continue;
		}
		cout << "\tВы ввели целое число m = " << n << endl;
		_LineStar100_

#pragma endregion
			// Решение задачи
		// так как для введенных данных решаються две задачи
		// сделаем копии, чтоб упростить нашу задачу
		int tmp_n = n, tmp_m = m, tmp_g = g;
		bool gv = ((g % 4 == 0) && (g % 100 != 0)) || (g % 400 == 0);
		n++;
		keyLoop = false;
		switch (m) {
		case 1: case 3: case 5: case 7: case 8: case 10: case 12: keyLoop = ((n >= 1) && (n <= 31)); break;
		case 4: case 6: case 9: case 11: keyLoop = ((n >= 1) && (n <= 30)); break;
		case 2: keyLoop = (gv) ? ((n >= 1) && (n <= 29)) : ((n >= 1) && (n <= 28)); break;
		default: break;
		}
		n = keyLoop ? n : 1; //уточним не начался ли следующий месяц
		m = (n == 1) ? ++m : m; //если новый месяц, то учтем это
		g = (m == 13) ? ++g : g; //если номер месяца указывает на новый год(13 месяц - январь следующего года)
		m = (m == 13) ? 1 : m; //скорректируем номер месяца даты

		if (n == 1) cout << "\tНовый месяц." << endl;
		if ((m == 1) && (n == 1)) cout << "\tНовый Год!!!." << endl;
		if ((((g % 4 == 0) && (g % 100 != 0)) || (g % 400 == 0)) && (m == 1) && (n == 1)) cout << "\tНовый год высокосный." << endl;

		cout << "\tДата следующего дня ГГ.ММ.ДД: " << setw(2) << setfill('0') << g%100 << "." << m << "." << n << endl;
		//Вывод результатов программы
		_LineStar100_


		n = tmp_n;
		g = tmp_g;
		m = tmp_m;
		n--;
		keyLoop = false;
		switch (m) {
		case 1: case 3: case 5: case 7: case 8: case 10: case 12: keyLoop = ((n >= 1) && (n <= 31)); break;
		case 4: case 6: case 9: case 11: keyLoop = ((n >= 1) && (n <= 30)); break;
		case 2: keyLoop = (gv) ? ((n >= 1) && (n <= 29)) : ((n >= 1) && (n <= 28)); break;
		default: break;
		}
		n = keyLoop ? n : 0; //уточним не вернулись ли мы на предыдущий месяц
		m = (n == 0) ? --m : m; //если предыдущий месяц, то учтем это
		g = (m == 0) ? --g : g; //если номер месяца указывает на новый год(13 месяц - январь следующего года)
		m = (m == 0) ? 12 : m; //скорректируем номер месяца даты
		// введем корректный номер дня
		keyLoop = false;
		if (m != tmp_m)
			switch (m) {
			case 1: case 3: case 5: case 7: case 8: case 10: case 12: n = 31; keyLoop = true; break;
			case 4: case 6: case 9: case 11: n = 30; keyLoop = true; break;
			case 2: n = (gv) ? (n = 29) : (n = 28); keyLoop = true; break;
			default: break;
			}

		if (keyLoop) cout << "\tПредыдущий месяц." << endl;
		if (g != tmp_g) cout << "\tСтарый Год!!!." << endl;
		if ((((g % 4 == 0) && (g % 100 != 0)) || (g % 400 == 0)) && (g != tmp_g)) cout << "\tСтарый год высокосный." << endl;

		cout << "\tДата предыдущего дня ГГ.ММ.ДД: " << setw(2) << setfill('0') << g % 100 << "." << m << "." << n << endl;
		//Вывод результатов программы
		_LineStar100_

#pragma region Pause
		cout << "\tПауза 5 секунд." << "      \r";
		Sleep(1000);
		for (int i = 5; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          ";
#pragma endregion

#pragma region keyRepeat
		int key; 
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch(); 

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	WINCLEAR;

	return 0;
}

