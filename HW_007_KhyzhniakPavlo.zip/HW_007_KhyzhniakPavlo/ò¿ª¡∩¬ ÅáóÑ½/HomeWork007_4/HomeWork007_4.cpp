﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 14.07.2019год.");

	//**************************************************************************
#pragma region Part01
	//Определение необходимых переменных
	int n;
	double a = 0, c = 0, h = 0, S = 0;

	while (true)
	{
#pragma region Copyright
		WINCLEAR;
		cout << "\n\n\n\n\n\n\n";
		cout << "                                  ___________________                        " << endl
			<< "                                 / _________________ \\                      " << endl
			<< "                                / /                 \\_|                     " << endl
			<< "               __________      / /                                           " << endl
			<< "              |_________ \\    / /                                           " << endl
			<< "                        | \\  / /                                            " << endl
			<< "                        |  \\/ /                                             " << endl
			<< "                        |    /                                               " << endl
			<< "                        |   /                                                " << endl
			<< "                        |  /                                                 " << endl
			<< "                        | /                                                  " << endl
			<< "                        |/                                                   " << endl;
		cout << "\n\n\n\n\n\n\n";
		cout << "\t\t\t\t© Pavlo Khyzhniak, 2019. При копировании материала ссылка на источник обязательна." << endl;
		//Sleep(1000);
#pragma endregion

		WINCLEAR;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		_LineStar100_

			cout << "\t\t\t\t" << " Ц И К Л И Ч Е С К И Е   О П Е Р А Ц И И " << endl;

		_LineStar100_

			cout << "\t\tЗадача 4. Сформировать набор случайных чисел, признак завершения набора - 0." << endl
			<< "\tВыводить эти числа по 10 в строку. Определить количество чисел в наборе, среднее" << endl
			<< "\tарифметическое чисел, меньших некоторого заданного числа К и количество таких" << endl
			<< "\tчисел(учтите, что количество может быть равно нулю, а на ноль делить нельзя)." << endl;

		//Ввод входных данных
		_LineStar100_

		bool keyLoop;
		keyLoop = true;
		double K;
		while (keyLoop) {
			cout << "\tВведите число K: ";
			//проверим правильность считываемых данных
			if (!(cin >> K)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				//if (K >= 0)
					break;
			}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы ввели число K = " << K << endl;

		// Решение задачи

		srand(time(0));
		cout << "\t";
		long long signed summa = 0, summaK = 0,counterK = 0, counter = 0, counterFix=1e5;
		for (;;) {
			//int tmp = -RAND_MAX + 2 * rand();
			int tmp = -10000 + rand() % 20000 + 1;
			
			if (tmp == 0) break;
			if (tmp < K) {
				summaK += tmp;
				++counterK;
			}
			counter++;
			cout << setw(6) << setfill(' ') << tmp << " ";
			if ((counter % 10 == 0) && (counter != 0)) {
				//сделаем точку останова в программе, вдруг ждать придеться долго))))
				if (counter >= counterFix) {
					cout << "\n\tУже вывели " << counter << " значений. Продолжить? Для повтора нажмите 'Y' или 'y'...\r";
					counterFix += 1e5;
					int in_key;
					in_key = _getch();
					if (in_key == 0 || in_key == 224) in_key = _getch();

					switch (in_key) {
					case 205:
					case 237:
					case 'Н':
					case 'н':
					case 'Y':
					case 'y': in_key = 0;  break;
					default: in_key = 1;  break;
					}
					if (in_key == 1) break;
				}
				cout << "                                                                                    \r\t";
			}
		}
		cout << endl;
		cout << "\tКоличество всех чисел = " << counter << endl;
		if (counterK != 0) cout << "\tСредне арифметическое чисел меньших K = " << K << " равно " << static_cast<double>(summaK) / counterK << endl;
		else cout << "\tСредне арифметическое чисел меньших K = " << K << " равно 0" << endl;
		cout << "\tКоличество чисел меньших K = " << K << " равно " << counterK << endl;

		//Вывод результатов программы
		_LineStar100_

#pragma region Pause
			cout << "\tПауза 5 секунд." << "      \r";
		Sleep(1000);
		for (int i = 5; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          ";
#pragma endregion

#pragma region keyRepeat
		int key;
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch();

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	WINCLEAR;

	return 0;
}

