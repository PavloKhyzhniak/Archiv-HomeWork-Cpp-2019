﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 14.07.2019год.");

	//**************************************************************************
#pragma region Part01
	//Определение необходимых переменных
	int n;
	double a = 0, c = 0, h = 0, S = 0;

	while (true)
	{
#pragma region Copyright
		WINCLEAR;
		cout << "\n\n\n\n\n\n\n";
		cout << "                                  ___________________                        " << endl
			<< "                                 / _________________ \\                      " << endl
			<< "                                / /                 \\_|                     " << endl
			<< "               __________      / /                                           " << endl
			<< "              |_________ \\    / /                                           " << endl
			<< "                        | \\  / /                                            " << endl
			<< "                        |  \\/ /                                             " << endl
			<< "                        |    /                                               " << endl
			<< "                        |   /                                                " << endl
			<< "                        |  /                                                 " << endl
			<< "                        | /                                                  " << endl
			<< "                        |/                                                   " << endl;
		cout << "\n\n\n\n\n\n\n";
		cout << "\t\t\t\t© Pavlo Khyzhniak, 2019. При копировании материала ссылка на источник обязательна." << endl;
		//Sleep(1000);
#pragma endregion

		WINCLEAR;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		_LineStar100_

		cout << "\t\t\t\t" << " Ц И К Л И Ч Е С К И Е   О П Е Р А Ц И И " << endl;

		_LineStar100_

		cout << "\t\tЗадача 3. Сформировать набор из N случайных чисел. Вывести эти числа, по 12 " << endl
			<< "\tв строку, найти сумму и количество нечетных положительных чисел в наборе." << endl;

		//Ввод входных данных
		_LineStar100_
					
		bool keyLoop;
		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите целое число N: ";
			//проверим правильность считываемых данных
			if (!(cin >> n)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				if (n >= 0) 
					break;
			}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы ввели целое число n = " << n << endl;
		
		// Решение задачи

		srand(time(0));
		cout << "\t";
		long long signed summa=0;
		long long signed summaPositiv = 0;
		int positiv=0;
		for (int i = 1; i <= n; i++) {
			int tmp = -RAND_MAX / 2 + rand();
			if ((tmp > 0) && (tmp % 2 != 0)) {
				summaPositiv+=tmp;
				++positiv;
			}
			summa += tmp;
			cout << setw(6) << setfill(' ') << tmp << " ";
			if ((i % 12 == 0) && (i != 0)) cout << "\n\t";
		}
		cout << endl;
		cout << "\tСумма всех чисел = " << summa << endl;
		cout << "\tСумма положительных нечетных чисел = " << summaPositiv << endl;
		cout << "\tКоличество положительных нечетных чисел = " << positiv << endl;

		//Вывод результатов программы
		_LineStar100_
				
#pragma region Pause
		cout << "\tПауза 5 секунд." << "      \r";
		Sleep(1000);
		for (int i = 5; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          ";
#pragma endregion

#pragma region keyRepeat
		int key; 
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch(); 

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	WINCLEAR;

	return 0;
}

