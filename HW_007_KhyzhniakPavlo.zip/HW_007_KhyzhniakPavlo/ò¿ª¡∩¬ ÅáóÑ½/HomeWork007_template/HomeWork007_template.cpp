﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 14.07.2019год.");

	//**************************************************************************
#pragma region Part01
	//Определение необходимых переменных
	int n=0;
	double a = 0;

	while (true)
	{
#pragma region Copyright
		WINCLEAR;
		cout << "\n\n\n\n\n\n\n";
		cout << "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl
			<< "                                                                             " << endl;
		cout << "\n\n\n\n\n\n\n";
		cout << "\t\t\t\t© Company, 2019. При копировании материала ссылка на источник обязательна." << endl;
		//Sleep(1000);
#pragma endregion

		WINCLEAR;
		//WINSETCONSOL_BLUE_ON_LTRED;
		srand(time(0));
		int t = rand() % 7;
		switch (t) {
		case 0: WINSETCONSOL_YELLOW_ON_LTMAGENTA; break;
		case 1: WINSETCONSOL_GRAY_ON_BLACK; break;
		case 2: WINSETCONSOL_BLUE_ON_LTRED; break;
		case 3: WINSETCONSOL_WHITE_ON_BLACK; break;
		case 4: WINSETCONSOL_GREEN_ON_GREY; break;
		case 5: WINSETCONSOL_GREEN_ON_LTWHITE; break;
		case 6: WINSETCONSOL_BLACK_ON_WHITE; break;
		case 7: WINSETCONSOL_GRAY_ON_GREEN; break;
		default: WINSETCONSOL_LTWHITE_ON_GREEN; break;
		}
		//Постановка решаемой задачи
		_LineStar100_

			cout << "\t\t\t\t" << " Тема задачи. " << endl;

		_LineStar100_

			cout << "\t\tЗадача. Условие задания. Техническая постановка задачи." << endl
				<< "\tУточнения, формулы." << endl;
			
		//Ввод входных данных
		_LineStar100_
#pragma region INPUT
		bool keyLoop;// введем вспомогательную переменную для организации циклического ввода данных
		keyLoop = true;// установим ей значение TRUE и запустим бесконечный цикл
		double K;
		while (keyLoop) {
			cout << "\tВведите число K: ";
			//проверим правильность считываемых данных
			if (!(cin >> K)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				if (K >= 0)
				break;//принудительный выход из цикла
			}
			//если не прошли валидацию данных
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;// перейти к следующей итерации цикла
		}
		cout << "\tВы ввели число K = " << K << endl;
#pragma endregion

		// Решение задачи
		
		cout << "\t";
		const long counterFixDelta = 1e1;
		long counter=0, counterFix = counterFixDelta;
		for (;;) {
			int tmp = -10000 + (rand() % 20000) + 1;//организуем генерацию чисел от -9999 до 20000 включительно

			if (counter == 100) break;//укажем условия прекращения бесконечного цикла

			counter++;// подсчитаем каждое сгенерированное число
			cout << setw(6) << setfill(' ') << tmp << " ";// выведем все числа
			
			//сделаем точку останова в программе, вдруг ждать придеться долго))))
			//рекомендуется всегда предусматривать принудительный выход из бесконечного цикла
			if (counter >= counterFix) {//сравним наш счетчик с указанным пределом
				cout << "\n\tУже вывели " << counter << " значений. Продолжить? Для повтора нажмите 'Y' или 'y'...\r";
				counterFix += counterFixDelta;//в случае желания Продолжить! увеличим предел до следующего порогового значения
				
				int in_key;//переменная для хранения считанного кода с клавиатуры
				in_key = _getch();
				if (in_key == 0 || in_key == 224) in_key = _getch();//в случае использования спец символов

				switch (in_key) {
				//проверим все значения(коды) кнопок 'Y' или 'y' с клавиатуры при разных раскладках
				case 205:
				case 237:
				case 'Н':
				case 'н':
				case 'Y':
				case 'y': in_key = 0;  break;
				default: in_key = 1;  break;
				}
				//в случае ввода других данных принудительный выход из бесконечного цикла
				if (in_key == 1) break;

				// очистка нашего вопроса-паузы
				cout << "                                                                                    \r\t";
			}
			
		}
		cout << endl;
		
		//Вывод результатов программы
		cout << "\tКоличество всех чисел = " << counter << endl;
		
		_LineStar100_

#pragma region Pause
		cout << "\tПауза 5 секунд." << "      \r";
		Sleep(1000);
		for (int i = 5; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          ";
#pragma endregion

#pragma region keyRepeat
		int key;//переменная для хранения считанного кода с клавиатуры
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch();//в случае использования спец символов

		switch (key) {
		//проверим все значения(коды) кнопок 'Y' или 'y' с клавиатуры при разных раскладках
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}
		//в случае ввода других данных принудительный выход из бесконечного цикла
		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GRAY_ON_BLACK;
	WINCLEAR;

	return 0;
}

