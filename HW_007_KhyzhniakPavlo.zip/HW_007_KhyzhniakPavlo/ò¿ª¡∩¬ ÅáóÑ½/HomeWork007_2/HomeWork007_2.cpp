﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 14.07.2019год.");

	//**************************************************************************
#pragma region Part01
	//Определение необходимых переменных
	int n;
	double a = 0, c = 0, h = 0, S = 0;

	while (true)
	{
#pragma region Copyright
		WINCLEAR;
		cout << "\n\n\n\n\n\n\n";
		cout << "                                  ___________________                        " << endl
			<< "                                 / _________________ \\                      " << endl
			<< "                                / /                 \\_|                     " << endl
			<< "               __________      / /                                           " << endl
			<< "              |_________ \\    / /                                           " << endl
			<< "                        | \\  / /                                            " << endl
			<< "                        |  \\/ /                                             " << endl
			<< "                        |    /                                               " << endl
			<< "                        |   /                                                " << endl
			<< "                        |  /                                                 " << endl
			<< "                        | /                                                  " << endl
			<< "                        |/                                                   " << endl;
		cout << "\n\n\n\n\n\n\n";
		cout << "\t\t\t\t© Pavlo Khyzhniak, 2019. При копировании материала ссылка на источник обязательна." << endl;
		//Sleep(1000);
#pragma endregion

		WINCLEAR;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		_LineStar100_

		cout << "\t\t\t\t" << " У С Л О В Н Ы Й   О П Е Р А Т О Р " << endl;

		_LineStar100_

		cout << "\t\tЗадача 2. Элементы равностороннего треугольника пронумерованы следующим" << endl
			<< "\tобразом: 1 - сторона а, 2 - радиус R1 вписанной окружности (R1=a*sqrt(3)/6)," << endl
			<< "\t3 - радиус R2 описанной окружности (R2=2*R1), 4 - площадь S (S=a*a*sqrt(3)/4)." << endl
			<< "\tДан номер одного из его элементов и его значение." << endl
			<< "\tВывести значения остальных элементов данного треугольника(в том же порядке)." << endl;

		//Ввод входных данных
		_LineStar100_

		cout << "\tОпределитесь с выбором:\n";
		cout << "\t1 - сторона а," << endl
			<< "\t2 - радиус R1 вписанной окружности (R1 = a * sqrt(3) / 6)," << endl
			<< "\t3 - радиус R2 описанной окружности (R2=2*R1)," << endl
			<< "\t4 - площадь S (S=a*a*sqrt(3)/4)" << endl;
		
		bool keyLoop;
		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите целое число: ";
			//проверим правильность считываемых данных
			if (!(cin >> n)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				if ((n >= 1) && (n <= 4)) 
					break;
			}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы выбрали n = " << n << endl;

		double value=0;
		double a = 0, S = 0, R1 = 0, R2 = 0;

		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите значение вышего выбора: ";
			//проверим правильность считываемых данных
			if (!(cin >> value)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				if (value >= 0)
					break;
			}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		
		cout << endl;
		switch (n) {
		case 1:	cout << "\tСторона а = "; a = value; break;
		case 2: cout << "\tРадиус R1 вписанной окружности = "; R1 = value; break;
		case 3: cout << "\tРадиус R2 описанной окружности = "; R2 = value; break;
		case 4:	cout << "\tПлощадь S = "; S = value; break;
		}
		cout << value << "\r";

		// Решение задачи
		switch (n) {
		case 1:	
			R1 = a * sqrt(3) / 6.;
			R2 = 2. * R1;
			S = a * a * sqrt(3) / 4.;
			break;
		case 2:
			a = 6. * R1 / sqrt(3);
			R2 = 2. * R1;
			S = 9. * R1 * R1 / sqrt(3);
			break;
		case 3:
			a = 3. * R2 / sqrt(3);
			R1 = R2 / 2.;
			S = 9. * R2 * R2 / 4. / sqrt(3);
			break;
		case 4:
			a = sqrt(4. * S / sqrt(3));
			R1 = sqrt(4. * S / sqrt(3)) * sqrt(3) / 6;
			R2 = 2 * sqrt(4. * S / sqrt(3)) * sqrt(3) / 6;
			break;
		}

		
		cout << "\t                                                \r";
		cout << "\tСторона а = " << a << endl;
		cout << "\tРадиус R1 вписанной окружности = " << R1 << endl;
		cout << "\tРадиус R2 описанной окружности = " << R2 << endl;
		cout << "\tПлощадь S = " << S << endl;

		//Вывод результатов программы
		_LineStar100_
				
#pragma region Pause
		cout << "\tПауза 5 секунд." << "      \r";
		Sleep(1000);
		for (int i = 5; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          ";
#pragma endregion

#pragma region keyRepeat
		int key; 
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch(); 

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	WINCLEAR;

	return 0;
}

