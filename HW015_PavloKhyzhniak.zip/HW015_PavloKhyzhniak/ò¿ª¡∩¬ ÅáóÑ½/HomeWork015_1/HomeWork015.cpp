﻿
#include "pch.h"
#include "Utils.h"
#include "Func.h"
#include "FuncPredicate.h"
#include "FuncTemplates.h"

#include "Application.h"

HANDLE hStdOut;
CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
WORD wOldColorAttrs;

wchar_t title[100] = L"КА \"ШАГ\" г.Донецк - Домашняя работа № 15 - на 29.09.2019год.";

int main()
{
	init();

	// Установим актуальный заголовок окна
	SetConsoleTitle(title);

	//**************************************************************************

// DO NOT USED we used rand_s();
//	srand(static_cast<unsigned int>(GetTickCount64()));
//	rand();

	try {
		
		//ДОМАШНЯЯ РАБОТА
		//написаны функции, сделано меню
		menu();
		
	}
	catch (exception ex) {  // обработка исключения
		SetConsoleTextAttribute(hStdOut, wAttributeWarning);
		cout << "\n\n"
			<< "\t\t                                                       \n"
			<< "\t\t    [Ошибка(уровень приложения)]                                           \n"
			<< "\t\t    " << left << setw(48) << ex.what() << right << "   \n"
			<< "\t\t                                                       \n"
			<< "\n\n\n\n\n\n\n\n\n\n\n\n";
		SetConsoleTextAttribute(hStdOut, wAttributeNormal);
		Pause();
	}
	//**************************************************************************


	SetConsoleTextAttribute(hStdOut, wAttributeSpecial);
	cout << "\n\n"
		<< "\t                                                       \n"
		<< "\t    [К сведению]                                       \n"
		<< "\t    Конец работы приложения                            \n"
		<< "\t                                                       \n"
		<< "\n\n\n\n\n\n\n\n\n\n\n\n\n";
	SetConsoleTextAttribute(hStdOut, wAttributeNormal);
	Pause(1);
	
	// Restore the original text colors. 
	SetConsoleTextAttribute(hStdOut, wOldColorAttrs);

	WINCLEAR;
	return 0;

}






