﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(1251);
	// для организации ввода на русском языке
	SetConsoleCP(1251);

	// Установим актуальный заголовок окна
	system("title Задание 2 от 2-06-2019 Абрамян М.Э. Задачник по программированию.");
	//	system("pause");
	system("cls");

	// Задача № 4
	
		cout << "\n\n\tЗадача № 004 \n";
		cout << "\tBegin 4. Дан диаметр окружности d.\n"
			<< "\tНайти его длинну L=Pi*d. В качестве значения Pi использовать 3,14.\n\n";
		double d4, L4;
		cout << "\tВведите диаметр окружности d : ";
		cin >> d4;
		cout << "\tВы ввели диаметр окружности d = " << d4 << endl;
		L4 = d4 * M_PI;
		cout << "\tДлинна окружности будет равна " << L4 << endl;
		cout << endl;
		cout << "\t\t\t\t       *****       \n";
		cout << "\t\t\t\t     **     **     \n";
		cout << "\t\t\t\t    **_______**   \n";
		cout << "\t\t\t\t    **  d    **   \n";
		cout << "\t\t\t\t     **     **    \n";
		cout << "\t\t\t\t       *****    \n";
		cout << "\n\n\n\n";
		system("pause");
		system("cls");

	system("color 07");
	// организуем паузу для фиксации результатов работы программы
	//Sleep(5000);
	//system("pause");

	return 0;

}

