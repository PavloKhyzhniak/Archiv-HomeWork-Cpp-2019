﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(1251);
	// для организации ввода на русском языке
	SetConsoleCP(1251);

	// Установим актуальный заголовок окна
	system("title Задание 2 от 2-06-2019 Абрамян М.Э. Задачник по программированию.");
	//	system("pause");
	system("cls");

	// Задача № 5
	
		cout << "\n\n\tЗадача № 005 \n";
		cout << "\tBegin 5. Дана длинна ребра куба a.\n"
			<< "\tНайти объем куба V=a*a*a и площадь его поверхности S=6*a*a.\n\n";
		double a5, V5, S5;
		cout << "\tВведите длинну ребра куба a : ";
		cin >> a5;
		cout << "\tВы ввели длинну ребра куба a = " << a5 << endl;
		V5 = a5 * a5 * a5;
		cout << "\tОбъем куба будет равен " << V5 << endl;
		S5 = 6 * a5 * a5;
		cout << "\tПлощадь поверхности куба будет равен " << S5 << endl;
		cout << endl;
		cout << "\t\t\t\t      ********\n";
		cout << "\t\t\t\t    * |    * *\n";
		cout << "\t\t\t\t  *   |  *   * a\n";
		cout << "\t\t\t\t********     *\n";
		cout << "\t\t\t\t*     /* * * *\n";
		cout << "\t\t\t\t*   /  *   * \n";
		cout << "\t\t\t\t* /    * *  a\n";
		cout << "\t\t\t\t********\n";
		cout << "\t\t\t\t   a  \n";
		cout << "\n\n\n\n";
		system("pause");
		system("cls");

	system("color 07");
	// организуем паузу для фиксации результатов работы программы
	//Sleep(5000);
	//system("pause");

	return 0;

}

