﻿

#include "pch.h"


int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(1251);
	// для организации ввода на русском языке
	SetConsoleCP(1251);

	// Установим актуальный заголовок окна
	system("title Задание 1 от 2-06-2019");
	system("pause");
	system("cls");

	int i1 = MAXINT, i2(MININT), i3{ 30 };
	char c1 = 0x30, c2('A'), c3{ '@' };
	bool b1 = FALSE, b2(TRUE), b3{ bool(13) };
	double d1 = 0.00000998877665544332211, d2(12e-3), d3{ 1234567890e+12 };
	float f1 = float(d1), f2(d2), f3{ float(d3) };

	// введем переменные для формирования ширины столбцов
	int col0, col1, col2, col3, col4;

	col0 = 15;
	col1 = col2 = 12;
	col3 = 30;
	col4 = 25;

	// первый вызов таблицы со значениями установленными при инициализации глобальных переменных
	system("color b4");

	cout << "\tТаблица №1\n";
	// начали таблицу с формирования заголовка
	// предусмотрим разделительные полосы для строк и столбцов << "-|-"
	// при разделении строк воспользуемся установкой символа заполнения << setfill('-')
	// ширину столбцов будем контроллировать << setw(col0)
	//

	cout << "\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "---" << setw(col1) << '-' << "---" << setw(col2) << '-' << "---" << setw(col3) << '-' << "---" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "Тип переменной" << right << " | " << setw(col1) << "Значение 1" << " | " << setw(col2) << "Значение 2" << " | " << setw(col3) << "Значение 3" << " | " << setw(col4) << "Примечание" << " |\n"

		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "int" << right << " | " << setw(col1) << i1 << " | " << setw(col2) << i2 << " | " << setw(col3) << i3 << " | " << setw(col4) << " " << " |\n"
		<< hex
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "int" << right << " | " << setw(col1) << i1 << " | " << setw(col2) << i2 << " | " << setw(col3) << i3 << " | " << setw(col4) << " hex " << " |\n"
		<< dec
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "char" << right << " | " << setw(col1) << c1 << " | " << setw(col2) << c2 << " | " << setw(col3) << c3 << " | " << setw(col4) << " " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< noboolalpha
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "bool" << right << " | " << setw(col1) << b1 << " | " << setw(col2) << b2 << " | " << setw(col3) << b3 << " | " << setw(col4) << " noboolalpha " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< boolalpha
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "bool" << right << " | " << setw(col1) << b1 << " | " << setw(col2) << b2 << " | " << setw(col3) << b3 << " | " << setw(col4) << " boolalpha " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " " << " |\n"
		<< setprecision(3)
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " setprecision(3) " << " |\n"
		<< setprecision(3) << fixed
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " fixed " << " |\n"
		<< scientific
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " scientific " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "float" << right << " | " << setw(col1) << f1 << " | " << setw(col2) << f2 << " | " << setw(col3) << f3 << " | " << setw(col4) << " " << " |\n"

		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "---" << setw(col1) << '-' << "---" << setw(col2) << '-' << "---" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n";
	// завершили таблицу
	cout << "Пауза 5 секунд" << "\r";
	Sleep(1000);
	cout << "Осталось ...4        " << "\r";
	Sleep(1000);
	cout << "Осталось ...3" << "\r";
	Sleep(1000);
	cout << "Осталось ...2" << "\r";
	Sleep(1000);
	cout << "Осталось ...1" << "\r";
	Sleep(1000);
	system("pause");
	system("cls");

	// второй вызов таблицы со значениями из задания
	i1 = -25; i2 = 252; i3 = -2018;
	c1 = 'э'; c2 = 'щ'; c3 = 'z';
	b1 = true; b2 = TRUE; b3 = false;
	d1 = 45.78; d2 = -2982.45; d3 = 1092.3443;
	f1 = -56.567f; f2 = 102.67f; f3 = -58403.4f;

	system("color e2");

	cout << "\tТаблица №2\n";
	// начали таблицу с формирования заголовка
	// предусмотрим разделительные полосы для строк и столбцов << "-|-"
	// при разделении строк воспользуемся установкой символа заполнения << setfill('-')
	// ширину столбцов будем контроллировать << setw(col0)
	//

	cout << "\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "---" << setw(col1) << '-' << "---" << setw(col2) << '-' << "---" << setw(col3) << '-' << "---" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "Тип переменной" << right << " | " << setw(col1) << "Значение 1" << " | " << setw(col2) << "Значение 2" << " | " << setw(col3) << "Значение 3" << " | " << setw(col4) << "Примечание" << " |\n"

		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "int" << right << " | " << setw(col1) << i1 << " | " << setw(col2) << i2 << " | " << setw(col3) << i3 << " | " << setw(col4) << " " << " |\n"
		<< hex
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "int" << right << " | " << setw(col1) << i1 << " | " << setw(col2) << i2 << " | " << setw(col3) << i3 << " | " << setw(col4) << " hex " << " |\n"
		<< dec
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "char" << right << " | " << setw(col1) << c1 << " | " << setw(col2) << c2 << " | " << setw(col3) << c3 << " | " << setw(col4) << " " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< noboolalpha
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "bool" << right << " | " << setw(col1) << b1 << " | " << setw(col2) << b2 << " | " << setw(col3) << b3 << " | " << setw(col4) << " noboolalpha " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< boolalpha
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "bool" << right << " | " << setw(col1) << b1 << " | " << setw(col2) << b2 << " | " << setw(col3) << b3 << " | " << setw(col4) << " boolalpha " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " " << " |\n"
		<< setprecision(3)
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " setprecision(3) " << " |\n"
		<< setprecision(3) << fixed
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " fixed " << " |\n"
		<< scientific
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " scientific " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "float" << right << " | " << setw(col1) << f1 << " | " << setw(col2) << f2 << " | " << setw(col3) << f3 << " | " << setw(col4) << " " << " |\n"

		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "---" << setw(col1) << '-' << "---" << setw(col2) << '-' << "---" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n";
	// завершили таблицу
	cout << "Пауза 5 секунд" << "\r";
	Sleep(5000);
	system("pause");
	system("cls");

	// третий вызов таблицы со значениями введенными пользователем
	system("color c1");

	cout << "\n\n\n\n\n";
	cout << "Введите три целых числа : ";
	cin >> i1 >> i2 >> i3;
	system("cls");

	cout << "\n\n\n\n\n";
	cout << "Введите три символа : ";
	cin >> c1 >> c2 >> c3;
	system("cls");

	cout << "\n\n\n\n\n";
	cout << "Введите три логических значения : ";
	cin >> b1 >> b2 >> b3;
	system("cls");

	cout << "\n\n\n\n\n";
	cout << "Введите три числа дробных числа (double).\n ";
	cout << "\tВведите первое дробное число (double): ";
	cin >> d1;
	cout << "\tВведите второе дробное число (double): ";
	cin >> d2;
	cout << "\tВведите третье дробное число (double): ";
	cin >> d3;
	system("cls");

	cout << "\n\n\n\n\n";
	cout << "Введите три числа дробных числа (float).\n ";
	cout << "\tВведите первое дробное число (float): ";
	cin >> f1;
	cout << "\tВведите второе дробное число (float): ";
	cin >> f2;
	cout << "\tВведите третье дробное число (float): ";
	cin >> f3;
	system("cls");

	system("color c1");

	cout << "\tТаблица №3\n";
	// начали таблицу с формирования заголовка
	// предусмотрим разделительные полосы для строк и столбцов << "-|-"
	// при разделении строк воспользуемся установкой символа заполнения << setfill('-')
	// ширину столбцов будем контроллировать << setw(col0)
	//

	cout << "\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "---" << setw(col1) << '-' << "---" << setw(col2) << '-' << "---" << setw(col3) << '-' << "---" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "Тип переменной" << right << " | " << setw(col1) << "Значение 1" << " | " << setw(col2) << "Значение 2" << " | " << setw(col3) << "Значение 3" << " | " << setw(col4) << "Примечание" << " |\n"

		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "int" << right << " | " << setw(col1) << i1 << " | " << setw(col2) << i2 << " | " << setw(col3) << i3 << " | " << setw(col4) << " " << " |\n"
		<< hex
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "int" << right << " | " << setw(col1) << i1 << " | " << setw(col2) << i2 << " | " << setw(col3) << i3 << " | " << setw(col4) << " hex " << " |\n"
		<< dec
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "char" << right << " | " << setw(col1) << c1 << " | " << setw(col2) << c2 << " | " << setw(col3) << c3 << " | " << setw(col4) << " " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< noboolalpha
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "bool" << right << " | " << setw(col1) << b1 << " | " << setw(col2) << b2 << " | " << setw(col3) << b3 << " | " << setw(col4) << " noboolalpha " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< boolalpha
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "bool" << right << " | " << setw(col1) << b1 << " | " << setw(col2) << b2 << " | " << setw(col3) << b3 << " | " << setw(col4) << " boolalpha " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " " << " |\n"
		<< setprecision(3)
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " setprecision(3) " << " |\n"
		<< setprecision(3) << fixed
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " fixed " << " |\n"
		<< scientific
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "double" << right << " | " << setw(col1) << d1 << " | " << setw(col2) << d2 << " | " << setw(col3) << d3 << " | " << setw(col4) << " scientific " << " |\n"
		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "-|-" << setw(col1) << '-' << "-|-" << setw(col2) << '-' << "-|-" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n"
		<< "\t" << "| " << setfill(' ') << setw(col0) << left << "float" << right << " | " << setw(col1) << f1 << " | " << setw(col2) << f2 << " | " << setw(col3) << f3 << " | " << setw(col4) << " " << " |\n"

		<< "\t" << "|-" << setfill('-') << setw(col0) << '-' << "---" << setw(col1) << '-' << "---" << setw(col2) << '-' << "---" << setw(col3) << '-' << "-|-" << setw(col4) << '-' << "-|\n";
	// завершили таблицу

	cout << "Пауза 5 секунд" << "\r";
	Sleep(5000);
	system("pause");
	system("cls");

	system("color 07");
	// организуем паузу для фиксации результатов работы программы
	//Sleep(5000);
	//system("pause");

	return 0;
}

//*****************************************************************************
//***

	
