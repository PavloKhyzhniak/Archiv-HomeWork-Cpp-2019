﻿
// Организуем файл подключаемых библиотек и других вспомогательных(организационных) действий
#include "pch.h"


// основная функция программы
int main()
{
	// сменим заголовок окна консоли
	system("title Домашняя работа ПВ-36 от 26.05.2019.");

	cout << endl << endl << "Press any key..." << endl;
	//system("help color");
	//system("help pause");
	cin.ignore();
	system("cls");

	// установим определение русской расскладки, если вдруг используеться другая
	setlocale(LC_ALL, "RUS");
	// установим раскладку 1251 для вывода
	SetConsoleOutputCP(1251);
	// установим раскладку 1251 для ввода
	SetConsoleCP(1251);

	// 1 - Первая часть домашнего задания
	// Вывести названия осенних и зимних месяцев – по одному названию в строке,
	// между выводами названий делайте паузу в 1 секунду, перед выводом осенних
	// месяцев установите желтый цвет фона и черные буквы, перед выводом зимних
	// месяцев установите белый фон и синие буквы


	//system("help color");
	//cin.ignore();
	//system("cls");

	system("title Задание №1. Выполнил Хижняк Павел");

	system("color f1");
	cout << "Январь - January" << endl;
	Sleep(1000);
	cout << "Февраль - February" << endl;
	Sleep(1000);
	/*
	system("color 2F");
	cout << "Март - March" << endl;
	Sleep(1000);
	cout << "Апрель - April" << endl;
	Sleep(1000);
	cout << "Май - May" << endl;
	Sleep(1000);
	system("color 2F");
	cout << "Июнь - June" << endl;
	Sleep(1000);
	cout << "Июль - July" << endl;
	Sleep(1000);
	cout << "Август - August" << endl;
	Sleep(1000);
	*/
	system("color e0");
	cout << "Сентябрь - September" << endl;
	Sleep(1000);
	cout << "Октябрь - Oktober" << endl;
	Sleep(1000);
	cout << "Ноябрь - November" << endl;
	Sleep(1000);
	system("color f1");
	cout << "Декабрь - December" << endl;
	Sleep(1000);

	system("color f0");
	cout << endl << endl << "Press any key..." << endl;
	cin.ignore();
	system("cls");

	//произведем очистку консоли перед завершением работы
	system("cls");
	return 0;
}
