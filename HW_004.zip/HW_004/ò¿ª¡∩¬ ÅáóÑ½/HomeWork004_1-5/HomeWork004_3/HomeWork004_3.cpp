﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 23.06.2019");
	WINCLEAR;

	//**************************************************************************
#pragma region Part03;
	double xGrad, xRad, x, y;
	WINSETCONSOL_BLUE_ON_LTRED;
	cout << "\n\n"
		<< "\t\t\t\tУ С Л О В Н Ы Й   О П Е Р А Т О Р" << endl
		<< "\n\n\t\tЗадача № 4.1. Рассчитать значение у при заданном значении х:" << endl
		<< "\t     { sin(x)*sin(x) , при x>0," << endl
		<< "\t у = {                         " << endl
		<< "\t     { 1 - 2*sin(x*x) в противном случае." << endl;

	cout << "\n\n";

	cout << "\tВведите угол в градусах x: ";
	cin >> xGrad;
	x = xGrad;
	cout << "\tВы ввели x = " << xGrad << " град. " << endl;
	xRad = xGrad * M_PI / 180;
	y = xGrad > 0 ? pow(sin(xRad), 2) : (1. - 2 * sin(xRad * xRad));
	cout << "\n\tПри данном x, y = " << y << endl;

	cout << "\n\n\n\n";
	cout << "Пауза 5 секунд" << "\r";
	Sleep(1000);
	cout << "Осталось ...4        " << "\r";
	Sleep(1000);
	cout << "Осталось ...3" << "\r";
	Sleep(1000);
	cout << "Осталось ...2" << "\r";
	Sleep(1000);
	cout << "Осталось ...1" << "\r";
	Sleep(1000);
	WINPAUSE;
	WINCLEAR;
#pragma endregion;
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	// организуем паузу для фиксации результатов работы программы
	//Sleep(5000);
	//WINPAUSE;

	return 0;

}

