
#include "pch.h"
#include "FuncTime.h"


char* displaySystemTime(void) {
	SYSTEMTIME st;

	GetSystemTime(&st);
	//char buf[100];
	sprintf_s(buf, 100, "The system time is: %02d:%02d", st.wHour, st.wMinute);

	return buf;
}

char* displayLocalTime(void) {
	SYSTEMTIME lt;

	GetLocalTime(&lt);
	//char buf[100];
	sprintf_s(buf, 100, "The local time is: %02d:%02d", lt.wHour, lt.wMinute);

	return buf;
}

char* displayLocalTimeRAW(void) {
	time_t rawtime;
	struct tm timeinfo;

	time(&rawtime);
	_localtime64_s(&timeinfo, &rawtime);
	//char buf[100];
	strftime(buf, 49, "The local time is: %H:%M", &timeinfo);

	return buf;
}
