#ifndef FUNC_H /* ����� */
#define FUNC_H /* �������������� ��������� - ������ */

void Line(int, char);

double sumNeg(size_t, double[]);
intmax_t findMax(size_t, double[]);
intmax_t findMin(size_t, double[]);
double multMaxMin(size_t, double[]);
long long mult2(size_t, int[]);
long long sumFirstLast0(size_t, int[]);

void sortBubblePosNeg(size_t N, int A[]);
void sortChoiceAscend(size_t N, double A[]);
intmax_t findLinearyVar3(size_t N, int A[], int key);
intmax_t findReversLinearyVar3(size_t N, int A[], int key);
intmax_t findBinaryVar1(size_t N, double A[], double key);

//Specialized templates can be implemented in an implementation file
//and the implementation doesn't have to be visible,
//but the specialization must be previously declared.


template <typename T>
void display(size_t N,const T* A,const char message[] = "������: ", int norm=10, int setwN=6) {
	cout << endl << "\t" << message << endl;
	int cnt = 0;
	for (size_t i = 0; i < N; i++) {
		cout << setw(setwN) << A[i] << " ";
		cnt++;
		if (cnt % norm == 0) cout << endl;
	}
	cout << endl;
}

template <typename T>
void display(size_t N, size_t M, const T* A, const char message[] = "������: ", int norm = 10, int setwN = 6) {
	cout << endl << "\t" << message << endl;
	cout << setprecision(2) << fixed;
	for (size_t i = 0; i < N; i++) {
		for (size_t j = 0; j < M; ) {
			cout << setw(setwN) << A[i * M + j++] << " ";
			if (j % norm == 0) cout << endl;
		}
		cout << endl;
	}
	cout << endl;
}

template <typename T>
T genRand(T min, T max) {
	if constexpr (is_same_v<T, int>) return static_cast<T>(min + rand() % (max - min + 1));
	else if constexpr (is_same_v<T, double>) 
		return static_cast<T>(min + (max - min + 1.) * rand() / RAND_MAX);
	else if constexpr (is_same_v<T, float>) 
		return static_cast<T>(min + (max - min + 1.f) * rand() / RAND_MAX);
	else if constexpr (is_same_v<T, char>) return static_cast<T>(65 + rand() % 26 + rand() % 2 * 32);
	else
		throw exception("Unknown type variable passed.");
	return rand();
}

template <typename T>
void genArray(size_t N,T *A,T min = - 100,T max = 100) {
	for (size_t i = 0; i < N; i++)
		A[i] = genRand(min, max);
}

template <typename T>
void genArray(size_t N, size_t M, T* A, T min = static_cast<T>(-100), T max = static_cast<T>(100)) {
	for (size_t i = 0; i < N; i++)
		for (size_t j = 0; j < N; j++)
			A[i * M + j] = genRand(min, max);
}

template <typename T>
void sortBubble(
	size_t N,
	T A[],
	bool(*criterion)(size_t i, size_t j, T A[]) =
		[](size_t i, size_t j, T A[])->bool {return ((A[i] > A[j]) ? true : false); })
{
	for (size_t i = 0; i < (N-1); i++) {
		for (size_t j = (i+1); j < N; j++) {
			if (criterion(i, j, A))
			//if (A[i] > A[j])
			{
				//swap(A[i], A[j]);
				T tmp = A[i];
				A[i] = A[j];
				A[j] = tmp;
			//	display(N, A);
			}
		}
	}
}

template <typename T>
void sortChoice(
	size_t N,
	T A[],
	void(*criterion)(size_t N, T A[],size_t i_key, size_t i) = 
		[](size_t N, T A[], size_t i_key, size_t i) 
	{
		for (size_t j = 1; j < (N - i); j++) 
			if (A[j] > A[i_key]) i_key = j;

			T tmp = A[i_key];
			A[i_key] = A[N - i - 1];
			A[N - i - 1] = tmp;
	})
{
	for (size_t i = 0; i < (N - 1); i++) {
		size_t i_key = 0;

		criterion(N, A, i_key, i);
	}
}

template <typename T>
intmax_t findLineary(
	size_t N,
	T A[],
	T key)
{
	for (size_t i = 0; i < N; i++) {
		if (A[i] == key) return i;
	}
	return -1;
}

template <typename T>
intmax_t findBinary(
	size_t N,
	T A[],
	T key)
{
	size_t start = 0, end = N - 1;
	while(start<end)
	{
		size_t index = start + (end - start)/2;
		if (A[index] == key) return index;
		
		if (A[index] > key) end = index - 1;
		else start = index + 1;
		
		cout << start << " " << index << " " << end << " " << endl;
	}	
	return -1;
}



#endif //FUNC_H
