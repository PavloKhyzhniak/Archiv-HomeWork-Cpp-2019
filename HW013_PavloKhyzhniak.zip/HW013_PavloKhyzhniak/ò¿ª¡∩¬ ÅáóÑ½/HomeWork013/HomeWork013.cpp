﻿
#include "pch.h"
#include "Utils.h"
#include "Func.h"
#include "FuncPredicate.h"
#include "FuncTemplates.h"
#include "FuncTime.h"
#include "FuncFile.h"
#include "Application.h"

HANDLE hStdout;
CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
WORD wOldColorAttrs;

wchar_t title[100] = L"Домашняя работа - на 15.09.2019год.";



void sortMy2(size_t = 100, int[] = { 0 }, bool criterium(int, int) = [](int A, int B) {return (A > B); });
void sortInsertion(size_t, int[], bool criterium(int, int) = [](int A, int B)->bool {return true; });
void testMySortFunction();

int main()
{
	init();

	// Установим актуальный заголовок окна
	SetConsoleTitle(title);

	//**************************************************************************

	srand(GetTickCount64());

	try {
		//Несколько функций по сортировке
		//вставка, через функцию сдвига части массива
		//сортировка с помощью доп массива индексов и рекурсии
		//надо бы инструмент для анализа производительности алгоритмов:)
		//как вариант - запуск функции сортировки в отдельном потоке без прерываний
		//testMySortFunction();

		//ДОМАШНЯЯ РАБОТА
		//написаны функции, сделано меню
		test();
		
		//Тестирование функций предикатов
		//TestFunctionPredicate();
	
		//Тестирование функций 
		//TestFunction();
	}
	catch (exception ex) {  // обработка исключения
		SetConsoleTextAttribute(hStdout, FOREGROUND_BLUE | BACKGROUND_RED | FOREGROUND_INTENSITY);
		cout << "\n\n"
			<< "\t\t                                                       \n"
			<< "\t\t    [Ошибка]                                           \n"
			<< "\t\t    " << left << setw(48) << ex.what() << right << "   \n"
			<< "\t\t                                                       \n"
			<< "\n\n\n\n\n\n\n\n\n\n\n\n";
		SetConsoleTextAttribute(hStdout, FOREGROUND_RED | FOREGROUND_INTENSITY);
		Pause();
	}
	//**************************************************************************


	SetConsoleTextAttribute(hStdout, FOREGROUND_BLUE | BACKGROUND_GREEN | FOREGROUND_INTENSITY);
	cout << "\n\n"
		<< "\t                                                       \n"
		<< "\t    [К сведению]                                       \n"
		<< "\t    Конец работы приложения                            \n"
		<< "\t                                                       \n"
		<< "\n\n\n\n\n\n\n\n\n\n\n\n\n";
	SetConsoleTextAttribute(hStdout, FOREGROUND_RED | FOREGROUND_INTENSITY);
	Pause(1);
	
	// Restore the original text colors. 
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);

	WINCLEAR;
	return 0;

}

void testMySortFunction() {
	int A[N] = { 0 };
	while (1) {
		cout << endl << "Сгенерируем массив целых чисел." << endl;
		genArray(N, A);
		display(N, A);

		cout << endl << "Отсортируем массив по возростанию целых чисел." << endl;
		sortInsertion(N, A, sortAscend);
		display(N, A);

		cout << endl << "Сгенерируем массив целых чисел." << endl;
		genArray(N, A);
		display(N, A);

		cout << endl << "Отсортируем массив по правилу: сначала отрицательные потом положительные." << endl;
		sortInsertion(N, A, sortNegativPositiv);
		display(N, A);

		//сортировка по возрастанию 
		cout << endl << "Отсортируем массив во возростанию целых чисел." << endl;
		sortMy2(N, A, sortAscend);
		display(N, A);

		_getch();
	}
}


void bufIndexFill(bool& run, size_t N, int A[], size_t i_buf, size_t bufIndex[], size_t& ready, bool criterium(int, int)) {
	//cout << "вошли в рекурсию - прямой проход\n";
	size_t i;
	for (i = bufIndex[i_buf] + 1; i < N; i++)
		//циклв рекурсивной функции всегда будет проходит до конца(за вычетом уже готовым позиций)
		if (criterium(A[bufIndex[i_buf]], A[i]))
		{
			//есть элемент удовлетворяющий критерию, заходим в рекурсию(прямой проход - заполнение буфера индексов)
			bufIndex[++i_buf] = i;
			bufIndexFill(run, N, A, i_buf, bufIndex, ready, criterium);
			if (!run) {
				//cout << "вышли из рекурсию - прямой проход\n";
				return;//условие выхода из рекурсии
			}
		}
	swap(A[N - 1], A[bufIndex[i_buf]]);//ставим найденный элемент в конец
	ready++;//отметим готовую позицию

	bufIndex[i_buf] = 0;//для удобства обнулим значение в буфере индексов

	//cout << endl << setw(25) << "Промежуточный массив:"; for (size_t t = 0; t < N; t++) cout << setw(4) << A[t] << " ";
	//cout << endl;

	if (i_buf == 0) {
		//в буфере индексов закончились элементы
		//cout << "вышли из рекурсию - прямой проход(*)\n";
		run = false;
		return;
	}
		
	//рекурсивный вызов функции на предмет не все ли мы индексы просмотрели(обратный проход - очистка буфера индексов)
	//cout << "вошли в рекурсию - обратный проход\n";
	bufIndexFill(run, (N - 1), A, --i_buf, bufIndex, ready, criterium);
	//cout << "вышли из рекурсию - обратный проход\n";
}


void sortMy2(const size_t N, int* A, bool criterium(int, int)) {
	size_t* bufIndex = (size_t*)calloc(N, sizeof(size_t));//создание буфера индексов
	size_t i_buf = 0;//индекс в bufIndex
	bufIndex[i_buf] = 0;//начнем с первого и найденный ставим в конец
	
	//cout << endl << setw(25) << "Исходный массив:"; for (size_t t = 0; t < N; t++) cout << setw(4) << A[t] << " ";
	
	bool run;//бит готовности к рекурсии - цепочка формируеться
	size_t ready = 0;
	for (size_t i = 0; i < (N - ready); )
	{
		run = true;//установим - цепочка формируеться
		bufIndexFill(run, (N - ready), A, i_buf, bufIndex, ready, criterium);
		//цепочка была обработана, начнем заново(новая итерация) с оставшимися элементами
	}
	//уничтожение буфера индексов
	free(bufIndex);
}

void rightShift(size_t N, int A[], bool criterium(int, int)) {
	int tmp = A[N - 1];//сохраняем элемент для Вставки
	size_t i;
	//ищем место вставки - сдвигая поочередно все элементы с конца
	for (i = N - 1; i > 0; i--)
		if (criterium(tmp, A[i - 1]))
		{
			A[i] = A[i - 1];
			continue;
		}
		else break;
	A[i] = tmp;//вставляем сохраненный элемент в найденную позицию
}

//сортировка Вставками с использование доп.функции сдвига всех элементов
void sortInsertion(size_t N, int A[], bool criterium(int, int)) {
	for (size_t i = 1; i < N; i++)
		if (criterium(A[i], A[i - 1]))
			rightShift(i + 1, A, criterium);//так как передаем максимальное количество то (индекс + 1)
}



















