﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 30.06.2019год.");
	WINCLEAR;

	//**************************************************************************
#pragma region Part01;
	while (1)
	{
		//Определение необходимых переменных
		double M, answer;
		int n;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		cout << "\n\n"
			<< "\t\t\t\t О П Е Р А Т О Р   В Ы Б О Р А " << endl
			<< "\n\n\t\tЗадача Case 7. Единицы массы пронумерованы следующим образом:" << endl
			<< "\t 1 - килограмм, 2 - миллиграмм, 3 - грамм, 4 - тонна, 5 - центнер." << endl
			<< "\tДан номер единицы массы (целое число в диапазоне 1-5) и масса тела в этих" << endl
			<< "\tединицах (вещественное число). Найти массу тела в килограммах." << endl;

		//Ввод входных данных
		cout << "\n\n";


		cout << "\tВыберите номер единицы массы: \n"
			<< "\t 1 - килограммы\n"
			<< "\t 2 - миллиграммы\n"
			<< "\t 3 - граммы\n"
			<< "\t 4 - тонны\n"
			<< "\t 5 - центнеры\n\n";
			
		cout << "\tВведите номер единицы массы: ";
		cin >> n;
		cout << "\tВы выбрали " << n << endl << endl;
		cout << "\tВведите массу тела M = ";
		cin >> M;
		cout << "\tВы ввели M = " << M << endl;

		switch (n)
		{
		case 1: answer = M; break;
		case 2: answer = M/1000000.; break;
		case 3: answer = M/1000.; break;
		case 4: answer = M*1000.; break;
		case 5: answer = M*100.; break;
		}

		//Вывод результатов программы
		cout << "\n\tМасса тела в килограммах равна " << answer << endl;
		
		PAUSE;
		PRESSKEY2;

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		//PRESSKEY;
		WINCLEAR;

		if (key == 1) break;

	}
#pragma endregion;
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	
	return 0;
}

