﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 30.06.2019год.");
	WINCLEAR;

	//**************************************************************************
#pragma region Part01;
	while (1)
	{
		//Определение необходимых переменных
		double A, B, C, min, max, tmp, answer;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		cout << "\n\n"
			<< "\t\t\t\t У С Л О В Н Ы Й   О П Е Р А Т О Р" << endl
			<< "\n\n\t\tЗадача If 13. Даны три числа. Найти среднее из них ( то есть" << endl
			<< "\tчисло, расположенное между наименьшим и наибольшим)." << endl;

		//Ввод входных данных
		cout << "\n\n";

		cout << "\tВведите переменную А = ";
		cin >> A;
		cout << "\tВы ввели А = " << A << endl;
		cout << "\tВведите переменную В = ";
		cin >> B;
		cout << "\tВы ввели В = " << B << endl;
		cout << "\tВведите переменную C = ";
		cin >> C;
		cout << "\tВы ввели C = " << C << endl;

		//найдем максимальное из трех чисел
		tmp = (B > C) ? B : C;
		max = (A > tmp) ? A : tmp;

		//найдем минимальное из трех чисел
		tmp = (B < C) ? B : C;
		min = (A < tmp) ? A : tmp;

		char ch;

		if (A == min)
			if (B == max) { answer = C; ch = 'C'; }
			else { answer = B; ch = 'B'; }
		else
			if (B == min)
				if (A == max) { answer = C; ch = 'C'; }
				else { answer = A; ch = 'A'; }
		else
			if (A == max) { answer = B; ch = 'B'; }
			else { answer = A; ch = 'A'; }
		
		//Вывод результатов программы
		cout << "\n\tСреднее значение из А, В и C: " << ch << " = " << answer << endl;

		PAUSE;
		PRESSKEY2;

		switch (key){
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		//PRESSKEY;
		WINCLEAR;
		
		if (key == 1) break;
				
	}
#pragma endregion;
	//**************************************************************************

	//**************************************************************************
#pragma region Part02;
	while (1)
	{
		//Определение необходимых переменных
		const int n = 3;
		double A[n], B[n];
		int answer;

		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		cout << "\n\n"
			<< "\t\t\t\t У С Л О В Н Ы Й   О П Е Р А Т О Р" << endl
			<< "\n\n\t\tЗадача If 13. Даны три числа. Найти среднее из них ( то есть" << endl
			<< "\tчисло, расположенное между наименьшим и наибольшим)." << endl;

		//Ввод входных данных
		cout << "\n\n";
				
		for (int i = 0; i < n; i++)
		{
			cout << "\tВведите " << i+1 << " переменную: ";
			cin >> A[i];
		}
		cout << endl;

		cout << "\n\tИсходный ряд:" << endl;
		cout << "\t";
		for (int i = 0; i < n; i++)
		{
			cout << A[i] << " ";
			B[i] = A[i]; //сделаем копию исходного ряда
		}
		cout << endl;

		//сортировка пузырьком
		for (int j = 1; j < n ; j++)
		{
			for (int i = 0; i < n - j; i++)
			{
				double tmp;
				if (A[i] > A[i + 1])
				{
					tmp = A[i + 1];
					A[i + 1] = A[i];
					A[i] = tmp;
				};
			}
			
			cout << "\n\tПроход № " << j << "-й" << endl;
			cout << "\t";
			for (int i = 0; i < n; i++)
				cout << A[i] << " ";
			cout << endl;
		}

		cout << "\n\tОтсортированный ряд:" << endl;
		cout << "\t";
		for (int i = 0; i < n; i++)
			cout << A[i] << " ";
		cout << endl;

		//Вывод результатов программы
		for (int i = 0; i < n; i++)
			if (A[1] == B[i]) answer = i;

		char ch;
		switch (answer) 
		{
		case 0: ch = 'A'; break;
		case 1: ch = 'B'; break;
		case 2: ch = 'C'; break;
		}

		cout << "\n\tСреднее значение из А, В и C: " << ch << " = " << B[answer] << endl;

		PAUSE;
		PRESSKEY2;

		switch (key) {
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		//PRESSKEY;
		WINCLEAR;

		if (key == 1) break;		
	}
#pragma endregion;
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	// организуем паузу для фиксации результатов работы программы
	//Sleep(5000);
	//WINPAUSE;

	return 0;

}

