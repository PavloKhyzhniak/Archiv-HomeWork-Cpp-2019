﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 30.06.2019год.");
	WINCLEAR;

	//**************************************************************************
#pragma region Part01;
	while (1)
	{
		//Определение необходимых переменных
		int d;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		cout << "\n\n"
			<< "\t\t\t\t О П Е Р А Т О Р   В Ы Б О Р А" << endl
			<< "\n\n\t\tЗадача Case 1.  Дано целое число в диапазоне 1-7. Вывести строку -" << endl
			<< "\tназвание дня недели, соответствующее данному числу (1 - \"понедельник\"," << endl
			<< "\t2 - \"вторник\" и т.д." << endl;


		//Ввод входных данных
		cout << "\n\n";

		cout << "\tВведите переменную d = ";
		cin >> d;
		cout << "\tВы ввели d = " << d << endl;
	
		//Вывод результатов программы

		switch (d)
		{
		case 1: cout << "\n\tДень недели: ПОНЕДЕЛЬНИК\n"; break;
		case 2: cout << "\n\tДень недели: ВТОРНИК\n"; break;
		case 3: cout << "\n\tДень недели: СРЕДА\n"; break;
		case 4: cout << "\n\tДень недели: ЧЕТВЕРГ\n"; break;
		case 5: cout << "\n\tДень недели: ПЯТНИЦА\n"; break;
		case 6: cout << "\n\tДень недели: СУББОТА\n"; break;
		case 7: cout << "\n\tДень недели: ВОСКРЕСЕНЬЕ\n"; break;
		default: cout << "\n\tНет такого дня недели :) \n"; break;
		}


		PAUSE;
		PRESSKEY2;

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		//PRESSKEY;
		WINCLEAR;

		if (key == 1) break;

	}
#pragma endregion;
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	
	return 0;
}

