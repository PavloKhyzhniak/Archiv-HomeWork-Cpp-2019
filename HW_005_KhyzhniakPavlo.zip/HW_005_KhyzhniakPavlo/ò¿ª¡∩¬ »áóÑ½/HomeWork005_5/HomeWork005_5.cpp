﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 30.06.2019год.");
	WINCLEAR;

	//**************************************************************************
#pragma region Part01;
	while (1)
	{
		//Определение необходимых переменных
		int M;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		cout << "\n\n"
			<< "\t\t\t\t О П Е Р А Т О Р   В Ы Б О Р А " << endl
			<< "\n\n\t\tЗадача Case 4. Дан номер месяца - целое число в диапазоне 1-12" << endl
			<< "\t(1 - январь, 2 - февраль и т.д.). Определить количество дней в этом"
			<< "\tмесяце для невисокосного года." << endl;

		//Ввод входных данных
		cout << "\n\n";

		cout << "\tВведите переменную M = ";
		cin >> M;
		cout << "\tВы ввели M = " << M << endl;

		//Вывод результатов программы

		switch (M)
		{
		case 1: cout << "\n\tВ Январе: 31 дней\n"; break;
		case 2: cout << "\n\tВ Феврале: 28 дней\n"; break;
		case 3: cout << "\n\tВ Марте: 31 дней\n"; break;
		case 4: cout << "\n\tВ Апреле: 30 дней\n"; break;
		case 5: cout << "\n\tВ Мае: 31 дней\n"; break;
		case 6: cout << "\n\tВ Июне: 30 дней\n"; break;
		case 7: cout << "\n\tВ Июле: 31 дней\n"; break;
		case 8: cout << "\n\tВ Августе: 31 дней\n"; break;
		case 9: cout << "\n\tВ Сентябре: 30 дней\n"; break;
		case 10: cout << "\n\tВ Октябре: 31 дней\n"; break;
		case 11: cout << "\n\tВ Ноябре: 30 дней\n"; break;
		case 12: cout << "\n\tВ Декабре: 31 дней\n"; break;
		default: cout << "\n\tНет такого месяца :) "; break;
		}


		PAUSE;
		PRESSKEY2;

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		//PRESSKEY;
		WINCLEAR;

		if (key == 1) break;

	}
#pragma endregion;
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	
	return 0;
}

