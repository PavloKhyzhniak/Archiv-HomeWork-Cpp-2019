﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 30.06.2019год.");
	WINCLEAR;

	//**************************************************************************
#pragma region Part01;
	while (1)
	{
		//Определение необходимых переменных
		double A, B, C, answer;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		cout << "\n\n"
			<< "\t\t\t\t У С Л О В Н Ы Й   О П Е Р А Т О Р" << endl
			<< "\n\n\t\tЗадача If 15. Дано три числа. Найти сумму двух наибольших из них." << endl
			<< "\t" << endl;

		//Ввод входных данных
		cout << "\n\n";

		cout << "\tВведите переменную А = ";
		cin >> A;
		cout << "\tВы ввели А = " << A << endl;
		cout << "\tВведите переменную В = ";
		cin >> B;
		cout << "\tВы ввели В = " << B << endl;
		cout << "\tВведите переменную C = ";
		cin >> C;
		cout << "\tВы ввели C = " << C << endl;


		if (A > B)
		{
			answer = A;
			answer += (B > C) ? B : C;
		}
		else if (B > C)
		{
			answer = B;
			answer += (A > C) ? A : C;
		}
		else
		{
			answer = C;
			answer += (A > B) ? A : B;
		}
		//Вывод результатов программы
		cout << "\n\tСумма двух наибольших из них равна " << answer << endl;

		PAUSE;
		PRESSKEY2;

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		//PRESSKEY;
		WINCLEAR;

		if (key == 1) break;

	}
#pragma endregion;
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;

	return 0;
}

