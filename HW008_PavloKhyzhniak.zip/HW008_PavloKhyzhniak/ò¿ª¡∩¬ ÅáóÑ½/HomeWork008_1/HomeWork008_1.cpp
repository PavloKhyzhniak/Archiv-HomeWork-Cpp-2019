﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа на 21.07.2019год.");

	//**************************************************************************

	HANDLE hStdout, hStdin;
	CONSOLE_SCREEN_BUFFER_INFO csbiInfo;

	//**************************************************************************

#pragma region Part01
	WORD wOldColorAttrs;

	// Get handles to STDIN and STDOUT. 

	hStdin = GetStdHandle(STD_INPUT_HANDLE);
	hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hStdin == INVALID_HANDLE_VALUE ||
		hStdout == INVALID_HANDLE_VALUE)
	{
		MessageBox(NULL, TEXT("GetStdHandle"), TEXT("Console Error"),
			MB_OK);
		return 1;
	}

	// Save the current text colors. 

	if (!GetConsoleScreenBufferInfo(hStdout, &csbiInfo))
	{
		MessageBox(NULL, TEXT("GetConsoleScreenBufferInfo"),
			TEXT("Console Error"), MB_OK);
		return 1;
	}

	wOldColorAttrs = csbiInfo.wAttributes;

	// Set the text attributes to draw red text on black background. 

	if (!SetConsoleTextAttribute(hStdout, FOREGROUND_RED |
		FOREGROUND_INTENSITY))
	{
		MessageBox(NULL, TEXT("SetConsoleTextAttribute"),
			TEXT("Console Error"), MB_OK);
		return 1;
	}

	while (true)
	{
		WINCLEAR;	
		//Постановка решаемой задачи
		_Line(100, '*')

			cout << "\t\t\t\t" << " М И Н И М У М Ы   И   М А К С И М У М Ы " << endl;

		_Line(100, '*')

			cout << "\t\tЗадача 1. В наборе из N случайных целых чисел найти номера первого" << endl
			<< "\tминимального и последнего максимального элемента из данного набора и вывести их" << endl
			<< "\tв указанном порядке." << endl;

		//Ввод входных данных
		_Line(100, '*')

			int n = 0;
		bool keyLoop;
		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите целое число N: ";
			//проверим правильность считываемых данных
			if (!(cin >> n)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				if (n >= 0)
					break;
			}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы ввели целое число n = " << n << endl;

		bool handWork = false;//ручной ввод последовательности
		
		int keyMode=0;
		cout << "\r\tДля ручного ввода набора чисел нажмите 'Y' или 'y'...";
		keyMode = _getch();
		if (keyMode == 0 || keyMode == 224) keyMode = _getch();

		switch (keyMode) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': handWork = true;  break;
		default: handWork = false;  break;
		}

		// Решение задачи
		srand(GetTickCount64());
		//srand(GetTickCount());
		//srand(time(0));
		int tmp=0, min, max, cnt = 0;
		int firstMin=0, lastMax=0;
		min = INT_MAX;
		max = -INT_MAX;
		cout << "\n\t";
		while (n > 0) {
			cnt++;
			tmp = -1000 + rand() % 2000 + 1;
			//*********				
			if (handWork) {
				keyLoop = true;
				while (keyLoop) {
					cout << "\n                                                                \r";
					cout << "\r\tВведите число последовательности (N==0 окончание ввода) : ";
					//проверим правильность считываемых данных
					if (!(cin >> tmp)) {
						cin.clear();//сброс состояния ошибки буффера ввода
						cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
					}
					else {
						//проверка введенных данных - валидация ввода
						//if (K > 0)
						break;
					}
					cout << "\tЗначение введено не корректно. Повторите ввод.\r";
					Sleep(1000);
					cout << "\t                                                    \r";
					continue;
				}
			}
			//*********

			if (min > tmp) {
				min = tmp;
				firstMin = cnt;
			};
			if (max <= tmp) {
				max = tmp;
				lastMax = cnt;
			};
			cout << setw(6) << tmp;
			if (cnt % 8 == 0) cout << "\n\t";
			n--;
		}
		cout << endl << "\tНомер последнего максимального числа = " << lastMax << " ,\n\tномер первого минимального числа =  " << firstMin << endl;

		//Вывод результатов программы
		_Line(100, '*')

#pragma region Pause
			cout << "\tПауза 5 секунд." << "      \r";
		Sleep(1000);
		for (int i = 5; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          ";
#pragma endregion

#pragma region keyRepeat
		int key=0;
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch();

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0; break;
		default: key = 1; break;
		}
		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	
	// Restore the original text colors. 
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);
	
	cout << "\n\n\n\n";
	WINCLEAR;

	return 0;
}

