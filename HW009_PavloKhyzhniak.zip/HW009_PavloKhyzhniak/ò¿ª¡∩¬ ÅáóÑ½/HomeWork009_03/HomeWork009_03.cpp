﻿
#include "pch.h"


int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - Массивы на 18.08.2019год.");

	//**************************************************************************

	HANDLE hStdout, hStdin;
	CONSOLE_SCREEN_BUFFER_INFO csbiInfo;

	//**************************************************************************

#pragma region Part01
	WORD wOldColorAttrs;

	// Get handles to STDIN and STDOUT. 

	hStdin = GetStdHandle(STD_INPUT_HANDLE);
	hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hStdin == INVALID_HANDLE_VALUE ||
		hStdout == INVALID_HANDLE_VALUE)
	{
		MessageBox(NULL, TEXT("GetStdHandle"), TEXT("Console Error"),
			MB_OK);
		return 1;
	}

	// Save the current text colors. 

	if (!GetConsoleScreenBufferInfo(hStdout, &csbiInfo))
	{
		MessageBox(NULL, TEXT("GetConsoleScreenBufferInfo"),
			TEXT("Console Error"), MB_OK);
		return 1;
	}

	wOldColorAttrs = csbiInfo.wAttributes;

	// Set the text attributes to draw red text on black background. 

	if (!SetConsoleTextAttribute(hStdout, FOREGROUND_RED |
		FOREGROUND_INTENSITY))
	{
		MessageBox(NULL, TEXT("SetConsoleTextAttribute"),
			TEXT("Console Error"), MB_OK);
		return 1;
	}

	while (true)
	{
		WINCLEAR;
		//Постановка решаемой задачи
		_Line(100, '*')

			cout << "\t\t\t\t" << " М А С С И В Ы " << endl;

		_Line(100, '*')

			cout << "\t\tЗадача 3. Дан массив A вещественных чисел, размер массива N. Вывести массив, выделяя" << endl
			<< "\tцветом элементы с нечетными номерами в порядке убывания номеров: An, An-2, An-4,..., A1." << endl
			<< "\tУсловный оператор не использовать. Найти также сумму элементов с нечетными номерами." << endl
			;

		//Ввод входных данных
		_Line(100, '*')

						
		int n = 0;
		double testArr[1000] = { 0 };
		
		bool keyLoop;
		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите целое число N(размер массива <=1000): ";
			//проверим правильность считываемых данных
			if (!(cin >> n)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				if ((n >= 0) && (n <= 1000))
					break;
			}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы ввели размер массива N = " << n << endl;

		bool handWork = false;//ручной ввод последовательности

		int keyMode = 0;
		cout << "\r\tДля ручного ввода набора чисел нажмите 'Y' или 'y'...";
		keyMode = _getch();
		if (keyMode == 0 || keyMode == 224) keyMode = _getch();

		switch (keyMode) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': handWork = true;  break;
		default: handWork = false;  break;
		}

		// Решение задачи

		srand(GetTickCount64());
		//srand(GetTickCount());
		//srand(time(0));

		cout << "\n\n\tИсходный массив[" << n << "]:\n\t";
		int i = 0;
		while (n > i) {
			double tmp;

			//*********				
			if (handWork) {
				keyLoop = true;
				while (keyLoop) {
					cout << "\n                                                                \r";
					cout << "\r\tВведите " << i << "-е число массива: ";
					//проверим правильность считываемых данных
					if (!(cin >> tmp)) {
						cin.clear();//сброс состояния ошибки буффера ввода
						cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
					}
					else {
						//проверка введенных данных - валидация ввода
						//if (K > 0)
						break;
					}
					cout << "\tЗначение введено не корректно. Повторите ввод.\r";
					Sleep(1000);
					cout << "\t                                                    \r";
					continue;
				}
			}
			else tmp = -100 + rand() % 200 + 1;
			//*********
			testArr[i++] = tmp;
			cout << fixed << setprecision(2) << setw(8) << tmp;
			if (i % 10 == 0) cout << "\n\t";
		}

		//Вывод результатов программы
		_Line(100, '*');

		int cnt = 0;

		cnt = 0;
		int cnt2 = 0, summa = 0;
		cout << "\n\tИсходный статический массив[" << n << "]:\n\t";
		for (auto i = n-1; i >=0 ;i--) {
			double tmp = testArr[i];
			SetConsoleTextAttribute(hStdout, FOREGROUND_RED |
				FOREGROUND_INTENSITY| (i&0x01));
			summa += (tmp*(i&0x01));
			cout << "A[" << setfill('0') << setw(3) << i << "] = " << setfill(' ');
			cout << fixed << setprecision(2) << setw(8) << tmp<<" ";
			if (++cnt % 6 == 0) cout << "\n\t";
			
		}
		SetConsoleTextAttribute(hStdout, FOREGROUND_RED |
			FOREGROUND_INTENSITY);

		cout << endl << endl;
		cout << "\n\tСумма чисел с нечетными номерами: " << summa << endl;
				
		Sleep(3000);
		_Line(100, '*');


#pragma region Pause
		unsigned short timePause = 3;
		cout << "\tПауза " << timePause << " секунд." << "      \r";
		Sleep(1000);
		for (int i = timePause; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          \n";
#pragma endregion

#pragma region keyRepeat
		int key = 0;
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch();

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0; break;
		default: key = 1; break;
		}
		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************


	// Restore the original text colors. 
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);

	cout << "\n\n\n\n";
	WINCLEAR;

	return 0;
}

