﻿
#include "pch.h"

// ВАРИАНТ 1 для цикла for-loop с динамическими массивами
//*****************
//создайте тонкую оболочку вокруг вашего динамически выделенного массива и предоставите функции-члены begin() и end():
template <typename T>
struct wrapped_array {
	wrapped_array(T* first, T* last) : begin_{ first }, end_{ last } {}
	wrapped_array(T* first, std::ptrdiff_t size)
		: wrapped_array{ first, first + size } {}

	T* begin() const noexcept { return begin_; }
	T* end() const noexcept { return end_; }

	T* begin_;
	T* end_;
};

template <typename T>
wrapped_array<T> wrap_array(T* first, std::ptrdiff_t size) noexcept
{
	return { first, size };
}

//for (auto&& i : wrap_array(array, size))
//std::cout << i << std::endl;
//*****************

// ВАРИАНТ 2 для цикла for-loop с динамическими массивами
//*****************
//Чтобы использовать цикл for-loop для диапазона, вам необходимо предоставить функции-члены begin() и end() 
//или перегрузить функции, не являющиеся членами begin() и end().
//В последнем случае вы можете обернуть свой диапазон в std::pair и перегрузить begin() и end() для следующих:
namespace std {
	template <typename T> T* begin(std::pair<T*, T*> const& p)
	{
		return p.first;
	}
	template <typename T> T* end(std::pair<T*, T*> const& p)
	{
		return p.second;
	}
}

//for (auto&& i : std::make_pair(array, array + size))
//cout << i << endl;
//*****************


int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - Массивы на 18.08.2019год.");

	//**************************************************************************

	HANDLE hStdout, hStdin;
	CONSOLE_SCREEN_BUFFER_INFO csbiInfo;

	//**************************************************************************

#pragma region Part01
	WORD wOldColorAttrs;

	// Get handles to STDIN and STDOUT. 

	hStdin = GetStdHandle(STD_INPUT_HANDLE);
	hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hStdin == INVALID_HANDLE_VALUE ||
		hStdout == INVALID_HANDLE_VALUE)
	{
		MessageBox(NULL, TEXT("GetStdHandle"), TEXT("Console Error"),
			MB_OK);
		return 1;
	}

	// Save the current text colors. 

	if (!GetConsoleScreenBufferInfo(hStdout, &csbiInfo))
	{
		MessageBox(NULL, TEXT("GetConsoleScreenBufferInfo"),
			TEXT("Console Error"), MB_OK);
		return 1;
	}

	wOldColorAttrs = csbiInfo.wAttributes;

	// Set the text attributes to draw red text on black background. 

	if (!SetConsoleTextAttribute(hStdout, FOREGROUND_RED |
		FOREGROUND_INTENSITY))
	{
		MessageBox(NULL, TEXT("SetConsoleTextAttribute"),
			TEXT("Console Error"), MB_OK);
		return 1;
	}

	while (true)
	{
		WINCLEAR;	
		//Постановка решаемой задачи
		_Line(100, '*')

			cout << "\t\t\t\t" << " М А С С И В Ы " << endl;

		_Line(100, '*')

			cout << "\t\tЗадача 1. Дан целочисленный массив размера N. Все его элементы:" << endl
			<< "\t - увеличить в 2 раза;" << endl
			<< "\t - уменьшить на число А;" << endl
			<< "\t - разделить на первый элемент." << endl
			;

		//Ввод входных данных
		_Line(100, '*')


		cout << "\n\tВместо динамически создаваемого массива, можно использовать статический" << endl
			<< "\tс заведомо большей размерностью: int testArr[1000]={0}; и N <= 1000 !!!\n\n";

		int n = 0;
		int testArr[1000] = { 0 };
		bool keyLoop;
		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите целое число N(размер массива): ";
			//проверим правильность считываемых данных
			if (!(cin >> n)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				if ((n >= 0) && (n<=1000))
					break;
			}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы ввели размер массива N = " << n << endl;

		bool handWork = false;//ручной ввод последовательности
		
		int keyMode=0;
		cout << "\r\tДля ручного ввода набора чисел нажмите 'Y' или 'y'...";
		keyMode = _getch();
		if (keyMode == 0 || keyMode == 224) keyMode = _getch();

		switch (keyMode) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': handWork = true;  break;
		default: handWork = false;  break;
		}

		// Решение задачи
		
		srand(GetTickCount64());
		//srand(GetTickCount());
		//srand(time(0));
		
		cout << "\n\t Исходный массив["<<n<<"]:\n\t";
		int *myArr=(int*)malloc(sizeof(int)*n);
		int i = 0;
		while (n > i) {
			int tmp;

			//*********				
			if (handWork) {
				keyLoop = true;
				while (keyLoop) {
					cout << "\n                                                                \r";
					cout << "\r\tВведите " << i << "-е число массива: ";
					//проверим правильность считываемых данных
					if (!(cin >> tmp)) {
						cin.clear();//сброс состояния ошибки буффера ввода
						cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
					}
					else {
						//проверка введенных данных - валидация ввода
						//if (K > 0)
						break;
					}
					cout << "\tЗначение введено не корректно. Повторите ввод.\r";
					Sleep(1000);
					cout << "\t                                                    \r";
					continue;
				}
			}
			else tmp = -100 + rand() % 200 + 1;
			//*********
			testArr[i] = tmp;// только для тестирования статического массива
			myArr[i++] = tmp;
			cout << setw(6) << tmp;
			if (i % 8 == 0) cout << "\n\t";
		}

		//Вывод результатов программы
		_Line(100, '*');

		int cnt = 0;
/*
		cout << "\n\t Исходный динамический массив[" << n << "]:\n\t";
		for (auto i = 0; i < n; i++) {
			cout << setw(6) << myArr[i];
			if (++cnt % 8 == 0) cout << "\n\t";
		}
		cout << endl << endl;
		*/
		cnt = 0;
		cout << "\n\t Исходный статический массив[" << n << "]:\n\t";
		for (auto i = 0; i < n; i++) {
			cout << setw(6) << testArr[i];
			if (++cnt % 8 == 0) cout << "\n\t";
		}
		cout << endl << endl;
/*
		cout << "\n\t - увеличим все элементы массива в 2 раза:\n\n\t";
		cnt = 0;
		// ВАРИАНТ 1 для цикла for-loop с динамическими массивами

		for (auto&& i : wrap_array(myArr,n)) {			
			cout << setw(6) << (i*2);
			if (++cnt % 8 == 0) cout << "\n\t";
		};
		cout << endl << endl;

		cout << "\n\t - увеличим все элементы массива в 2 раза:\n\n\t";

		// ВАРИАНТ 2 для цикла for-loop с динамическими массивами
		cnt = 0;
		for (auto&& i : std::make_pair(myArr, myArr + n)){
			cout << setw(6) << (i * 2);
			if (++cnt % 8 == 0) cout << "\n\t";
		};
		cout << endl << endl;
		*/
		cout << "\n\t - увеличим все элементы массива в 2 раза:\n\n\t";
		cnt = 0;
		// ВАРИАНТ 3 для цикла for с динамическими массивами
		for (auto i = 0; i < n;i++)  {
			cout << setw(6) << (myArr[i] * 2);
			if (++cnt % 8 == 0) cout << "\n\t";
		}
		cout << endl << endl;
		Sleep(3000);
		_Line(100, '*');


		int A = 0;
		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите целое число A: ";
			//проверим правильность считываемых данных
			if (!(cin >> A)) {
				cin.clear();//сброс состояния ошибки буффера ввода
				cin.ignore(cin.rdbuf()->in_avail());//очистка буффера ввода от недопустимых символов
			}
			else {
				//проверка введенных данных - валидация ввода
				//if (n >= 0)
					break;
			}
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы ввели A = " << A << endl;

		cnt = 0;
		cout << "\n\t Исходный массив[" << n << "]:\n\t";
		for (auto i = 0; i < n; i++) {
			cout << setw(6) << myArr[i];
			if (++cnt % 8 == 0) cout << "\n\t";
		}
		cout << endl << endl;
/*
		cout << "\n\t - уменьшим все элементы массива на число А:\n\n\t";
		cnt = 0;
		// ВАРИАНТ 1 для цикла for-loop с динамическими массивами

		for (auto&& i : wrap_array(myArr, n)) {
			cout << setw(6) << (i - A);
			if (++cnt % 8 == 0) cout << "\n\t";
		};
		cout << endl << endl;

		cout << "\n\t - уменьшим все элементы массива на число А:\n\n\t";

		// ВАРИАНТ 2 для цикла for-loop с динамическими массивами
		cnt = 0;
		for (auto&& i : std::make_pair(myArr, myArr + n)) {
			cout << setw(6) << (i - A);
			if (++cnt % 8 == 0) cout << "\n\t";
		};
		cout << endl << endl;
		*/
		cout << "\n\t - уменьшим все элементы массива на число А:\n\n\t";
		cnt = 0;
		// ВАРИАНТ 3 для цикла for с динамическими массивами
		for (auto i = 0; i < n; i++) {
			cout << setw(6) << (myArr[i] - A);
			if (++cnt % 8 == 0) cout << "\n\t";
		}
		cout << endl << endl;

		Sleep(3000);
		_Line(100, '*');

		cnt = 0;
		cout << "\n\t Исходный массив[" << n << "]:\n\t";
		for (auto i = 0; i < n; i++) {
			cout << setw(6) << myArr[i];
			if (++cnt % 8 == 0) cout << "\n\t";
		}
		cout << endl << endl;
/*
		cout << "\n\t - разделим все элементы массива первый элемент этого массива:\n\n\t";
		cnt = 0;
		// ВАРИАНТ 1 для цикла for-loop с динамическими массивами

		for (auto&& i : wrap_array(myArr, n)) {
			cout << setw(6) << static_cast<int>(i/myArr[0]);
			if (++cnt % 8 == 0) cout << "\n\t";
		};
		cout << endl << endl;

		cout << "\n\t - разделим все элементы массива первый элемент этого массива:\n\n\t";

		// ВАРИАНТ 2 для цикла for-loop с динамическими массивами
		cnt = 0;
		for (auto&& i : std::make_pair(myArr, myArr + n)) {
			cout << setw(6) << static_cast<int>(i/myArr[0]);
			if (++cnt % 8 == 0) cout << "\n\t";
		};
		cout << endl << endl;
		*/
		cout << "\n\t - разделим все элементы массива первый элемент этого массива:\n\n\t";
		cnt = 0;
		// ВАРИАНТ 3 для цикла for с динамическими массивами
		for (auto i = 0; i < n; i++) {
			cout << setw(6) << (myArr[i]/myArr[0]);
			if (++cnt % 8 == 0) cout << "\n\t";
		}
		cout << endl << endl;

		cout << "\n\t - разделим все элементы массива первый элемент этого массива:\n\n\t";
		cnt = 0;
		// специально покажем дробные значения
		for (auto i = 0; i < n; i++) {
			cout << setprecision(2) << fixed << setw(6) << (static_cast<float>(myArr[i]) / myArr[0]);
			if (++cnt % 8 == 0) cout << "\n\t";
		}
		cout << endl << endl;

		Sleep(3000);
		_Line(100, '*');

#pragma region Pause
		unsigned short timePause = 3;
		cout << "\tПауза " << timePause << " секунд." << "      \r";
		Sleep(1000);
		for (int i = timePause; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          \n";
#pragma endregion

#pragma region keyRepeat
		int key=0;
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch();

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0; break;
		default: key = 1; break;
		}
		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	
	// Restore the original text colors. 
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);
	
	cout << "\n\n\n\n";
	WINCLEAR;

	return 0;
}

