﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - Задачник по программированию Абрамян М.Э. на 06.07.2019год.");

	//**************************************************************************
#pragma region Part01
	//Определение необходимых переменных
	double p ,h;
	const double p0 = 1.29, z = 1.25e-4;

	while (true)
	{
#pragma region Copyright
		WINCLEAR;
		cout << "\n\n\n\n\n\n\n";
		cout << "                                  ___________________                        " << endl
			<< "                                 / _________________ \\                      " << endl
			<< "                                / /                 \\_|                     " << endl
			<< "               __________      / /                                           " << endl
			<< "              |_________ \\    / /                                           " << endl
			<< "                        | \\  / /                                            " << endl
			<< "                        |  \\/ /                                             " << endl
			<< "                        |    /                                               " << endl
			<< "                        |   /                                                " << endl
			<< "                        |  /                                                 " << endl
			<< "                        | /                                                  " << endl
			<< "                        |/                                                   " << endl;
		cout << "\n\n\n\n\n\n\n";
		cout << "\t\t\t\t© Pavlo Khyzhniak, 2019. При копировании материала ссылка на источник обязательна." << endl;
		//Sleep(1000);
#pragma endregion

		WINCLEAR;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

		cout << "\t\t\t\t" << " О П Е Р А Т О Р   Ц И К Л А   С   П А Р А М Е Т Р О М " << endl;

		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

		cout << "\t\tЗадача 5.12. Плотность воздуха убывает с высотой по закону p=p0*exp(-h*z)," << endl
			<< "\tгде p - плотность на высоте h метров, p0=1,29 кг/м3, z = 1,25e-4." << endl
			<< "\tНапечатать таблицу зависимости плотности от высоты для значений" << endl
			<< "\tот 0 до 1000 м через каждые 100м." << endl;

		//Ввод входных данных
		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

		
		// Решение задачи
		cout << "\tЗависимость плотности воздуха от высоты над уровнем моря:\n";
		cout << "\t h,m" << "\tp,kg/m3\t\tграфическое отображение величины p" << endl; 
		for ( h = 100.; h <= 1000.; h += 100.) {
			p = p0 * exp(-h * z);
			cout << "\t" << setw(7) << setprecision(2) << fixed << right  << h << "\t  " << p << "\t|";
			for (int i = 0; i < ((p-1) * 300); i++, cout << "*");
			cout << "|\n";
		}

		//Вывод результатов программы
		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;
		
		/*
		cout << endl << endl;
		int j=1;
		while (j++ < 100) cout << "*";
		cout << endl << endl << endl;
		*/

		/*
		cout << endl << endl;
		int j = 1;
		do
		{
			cout << "*";
		} while (j++ < 100);
		cout << endl << endl << endl;
		*/
#pragma region Pause
		cout << "\tПауза 5 секунд." << "      \r";
		Sleep(1000);
		for (int i = 5; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          ";
#pragma endregion

#pragma region keyRepeat
		int key; 
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch(); 

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	WINCLEAR;

	return 0;
}

