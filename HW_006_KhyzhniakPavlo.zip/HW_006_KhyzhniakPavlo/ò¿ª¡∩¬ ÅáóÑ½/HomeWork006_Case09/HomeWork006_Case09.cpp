﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - Задачник по программированию Абрамян М.Э. на 06.07.2019год.");

	//**************************************************************************
#pragma region Part01
	//Определение необходимых переменных
	int D, M;

	while (true)
	{
#pragma region Copyright
		WINCLEAR;
		cout << "\n\n\n\n\n\n\n";
		cout << "                                  ___________________                        " << endl
			<< "                                 / _________________ \\                      " << endl
			<< "                                / /                 \\_|                     " << endl
			<< "               __________      / /                                           " << endl
			<< "              |_________ \\    / /                                           " << endl
			<< "                        | \\  / /                                            " << endl
			<< "                        |  \\/ /                                             " << endl
			<< "                        |    /                                               " << endl
			<< "                        |   /                                                " << endl
			<< "                        |  /                                                 " << endl
			<< "                        | /                                                  " << endl
			<< "                        |/                                                   " << endl;
		cout << "\n\n\n\n\n\n\n";
		cout << "\t\t\t\t© Pavlo Khyzhniak, 2019. При копировании материала ссылка на источник обязательна." << endl;
		//Sleep(1000);
#pragma endregion

		WINCLEAR;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		cout << "\n\n"
			<< "\t\t\t\t О П Е Р А Т О Р   В Ы Б О Р А " << endl
			<< "\n\n\t\tЗадача Case 09. Даны два целых числа: D (день) и M (месяц)," << endl
			<< "\tопределяющие правильную дату невысокосного года. Вывести значения D и M" << endl
			<< "\tдля даты, следующей за указанной." << endl;

		//Ввод входных данных
		cout << "\n\n";

		int G;
		bool keyLoop;
		bool gv = false;// по умолчанию год невысокосный

		// на основании введенного года можно учитывать высокосный или невысокосный год
/*		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите год G = ";
			cin >> G;
			if (G >= 0) break;
			cout << "\n\tЗначение года введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы ввели год G = " << G << endl;
		gv = (((G % 4 == 0) && (G % 100 != 0)) || (G % 400 == 0));
		if (gv) cout << "\n\tДанный год высокосный" << endl;
		else cout << "\n\tДанный год невысокосный" << endl;
	*/	

		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите день D = ";
			cin >> D;
			if ((D >= 1) && (D <= 31)) break;
			cout << "\n\tЗначение дня введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы ввели день D = " << D << endl;


		keyLoop = true;
		while (keyLoop) {
			cout << "\tВведите месяц M = ";
			cin >> M;
			switch (M) {
			case 1: case 3: case 5: case 7: case 8: case 10: case 12: keyLoop = (D <= 31); break;
			case 4: case 6: case 9: case 11: keyLoop = (D <= 30); break;
			case 2: keyLoop = (gv) ? (D <= 29) : (D <= 28); break;
			default:
				cout << "\n\tЗначение месяца введено не корректно. Повторите ввод.\r";
				Sleep(1000);
				cout << "\t                                                       \r";
				continue;
			}
			if (!keyLoop) {
				cout << "\n\tЗначение дня не соответствует месяцу. Повторите ввод.\r";
				Sleep(1000);
				cout << "\t                                                       \r";
				continue;
			}
			break;
		}
		if (!keyLoop) continue;
		cout << "\tВы ввели месяц M = " << M << endl;

		// Решение задачи
		D++;
		switch (M) {
		case 1: case 3: case 5: case 7: case 8: case 10: case 12: 
			D = (D <= 31) ? D : 1;
			M = (D == 1) ? ++M : M;
			break;
		case 4: case 6: case 9: case 11: 
			D = (D <= 30) ? D : 1;
			M = (D == 1) ? ++M : M;
			break;
		case 2: 
			D = (gv) ? ((D <= 29) ? D : 1) : ((D <= 28) ? D : 1);
			M = (D == 1) ? ++M : M;
			break;
		}
		M = (M > 12) ? 1 : M;

		if ((D == 1) && !(M == 1)) cout << "\n\tПОЗДРАВЛЯЕМ!!! Наступил новый месяц!" << endl;
		if ((D == 1) && (M == 1)) cout << "\n\tПОЗДРАВЛЯЕМ!!! Наступил НОВЫЙ ГОД!" << endl;

		//Вывод результатов программы
		cout << "\n\tСледующая дата: ";
			switch (M) {
			case 12: cout << "Декабрь"; break;
			case 11: cout << "Ноябрь"; break;
			case 10: cout << "Октябрь"; break;
			case 9: cout << "Сентябрь"; break;
			case 8: cout << "Август"; break;
			case 7: cout << "Июль"; break;
			case 6: cout << "Июнь"; break;
			case 5: cout << "Май"; break;
			case 4: cout << "Апрель"; break;
			case 3: cout << "Март"; break;
			case 2: cout << "Февраль"; break;
			case 1: cout << "Январь"; break;
			}
			cout << " " << D << endl;

#pragma region Pause
		cout << "\n\n\n\n\tПауза 5 секунд." << "      \r";
		Sleep(1000);
		for (int i = 5; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          ";
#pragma endregion

#pragma region keyRepeat
		int key; 
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch(); 

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	WINCLEAR;

	return 0;
}

