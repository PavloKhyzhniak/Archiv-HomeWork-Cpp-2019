﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - Задачник по программированию Абрамян М.Э. на 06.07.2019год.");

	//**************************************************************************
#pragma region Part01
	//Определение необходимых переменных
	int n;
	double a = 0, c = 0, h = 0, S = 0;

	while (true)
	{
#pragma region Copyright
		WINCLEAR;
		cout << "\n\n\n\n\n\n\n";
		cout << "                                  ___________________                        " << endl
			<< "                                 / _________________ \\                      " << endl
			<< "                                / /                 \\_|                     " << endl
			<< "               __________      / /                                           " << endl
			<< "              |_________ \\    / /                                           " << endl
			<< "                        | \\  / /                                            " << endl
			<< "                        |  \\/ /                                             " << endl
			<< "                        |    /                                               " << endl
			<< "                        |   /                                                " << endl
			<< "                        |  /                                                 " << endl
			<< "                        | /                                                  " << endl
			<< "                        |/                                                   " << endl;
		cout << "\n\n\n\n\n\n\n";
		cout << "\t\t\t\t© Pavlo Khyzhniak, 2019. При копировании материала ссылка на источник обязательна." << endl;
		//Sleep(1000);
#pragma endregion

		WINCLEAR;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

		cout << "\t\t\t\t" << " О П Е Р А Т О Р   В Ы Б О Р А " << endl;

		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

		cout << "\t\tЗадача Case 13. Элементы равнобедренного прямоугольного треугольника пронумерованы" << endl
			<< "\tследующим образом: 1 - катет a, 2 - гипотенуза c = a*sqrt(2), 3 - высота h, опущенная на" << endl
			<< "\tгипотенузу(h=c/2), 4 - площадь S = c*h/2. Дан номер одного из этих элементов и его значение" << endl
			<< "\tВывести значения остальных элементов данного треугольника(в том же порядке)." << endl;

		//Ввод входных данных
		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

		cout << "\t 1 - Катет равнобедренного прямоугольного треугольника        " << endl
			<< "\t 2 - Гипотенуза равнобедренного прямоугольного треугольника   " << endl
			<< "\t 3 - Высота равнобедренного прямоугольного треугольника       " << endl
			<< "\t 4 - Площадь равнобедренного прямоугольного треугольника      " << endl;

		bool keyLoop;
		keyLoop = true;
		while (keyLoop) {
			cout << "\tВыберите номер заданного элемента: ";
			cin >> n;
			if ((n >= 1) && (n <= 4)) break;
			cout << "\tЗначение введено не корректно. Повторите ввод.\r";
			Sleep(1000);
			cout << "\t                                                    \r";
			continue;
		}
		cout << "\tВы выбрали элемент  n = " << n << endl;
		
		cout << "\n\tВведите значение заданного элемента: \n\t";
		switch (n) {
		case 1: cout << " 1 - Катет равнобедренного прямоугольного треугольника      = "; cin >> a; break;
		case 2: cout << " 2 - Гипотенуза равнобедренного прямоугольного треугольника = "; cin >> c; break;
		case 3: cout << " 3 - Высота равнобедренного прямоугольного треугольника     = "; cin >> h; break;
		case 4: cout << " 4 - Площадь равнобедренного прямоугольного треугольника    = "; cin >> S; break;
		default: cout << "Элемент задан неверно."; break;
		}
		
		// Решение задачи
		switch (n) {
		case 1:
			//a;
			c = a * M_SQRT2;
			h = a / M_SQRT2;
			S = a * a / 2.;
			break;
		case 2:
			a = c / M_SQRT2;
			//c;
			h = c / 2.;
			S = c * c / 4.;
			break;
		case 3:
			a = 2. * h / M_SQRT2;
			c = 2. * h;
			//h;
			S = h * h;
			break;
		case 4:
			a = M_SQRT2 * sqrt(S);
			c = 2. * sqrt(S);
			h = sqrt(S);
			//S;
			break;
		};


		//Вывод результатов программы
		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

		cout << "\t 1 - Катет равнобедренного прямоугольного треугольника      = " << a << endl
			<< "\t 2 - Гипотенуза равнобедренного прямоугольного треугольника = " << c << endl
			<< "\t 3 - Высота равнобедренного прямоугольного треугольника     = " << h << endl
			<< "\t 4 - Площадь равнобедренного прямоугольного треугольника    = " << S << endl;
		
		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;
				
#pragma region Pause
		cout << "\tПауза 5 секунд." << "      \r";
		Sleep(1000);
		for (int i = 5; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          ";
#pragma endregion

#pragma region keyRepeat
		int key; 
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch(); 

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	WINCLEAR;

	return 0;
}

