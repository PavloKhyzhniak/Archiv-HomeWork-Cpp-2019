﻿
#include "pch.h"

int main()
{
	// для организации вывода на русском языке
	SetConsoleOutputCP(CODE_PAGE);
	// для организации ввода на русском языке
	SetConsoleCP(CODE_PAGE);

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - Сборник задач по программированию 2011год. Златопольский Д.М. на 06.07.2019год.");

	//**************************************************************************
#pragma region Part01
	//Определение необходимых переменных
	double R, h, L;

	while (true)
	{
#pragma region Copyright
		WINCLEAR;
		cout << "\n\n\n\n\n\n\n";
		cout << "                                  ___________________                        " << endl
			<< "                                 / _________________ \\                      " << endl
			<< "                                / /                 \\_|                     " << endl
			<< "               __________      / /                                           " << endl
			<< "              |_________ \\    / /                                           " << endl
			<< "                        | \\  / /                                            " << endl
			<< "                        |  \\/ /                                             " << endl
			<< "                        |    /                                               " << endl
			<< "                        |   /                                                " << endl
			<< "                        |  /                                                 " << endl
			<< "                        | /                                                  " << endl
			<< "                        |/                                                   " << endl;
		cout << "\n\n\n\n\n\n\n";
		cout << "\t\t\t\t© Pavlo Khyzhniak, 2019. При копировании материала ссылка на источник обязательна." << endl;
		//Sleep(1000);
#pragma endregion

		WINCLEAR;
		WINSETCONSOL_BLUE_ON_LTRED;
		//Постановка решаемой задачи
		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

		cout << "\t\t\t\t" << " О П Е Р А Т О Р   Ц И К Л А   С   П А Р А М Е Т Р О М " << endl;

		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

		cout << "\t\tЗадача 5.11. Считая, что Земля - идеальная сфера с радиусом R = 6350 км.," << endl
			<< "\tопределить расстояние до линии горизонта от точки с высотой над Землей, равной 1,2, ..." << endl
			<< "\t10 км." << endl;

		cout << "\t\tРасстояние L до линии горизонта от точки с высотой h для планеты" << endl
			<< "\tс радиусом R определяется формулой:" << endl
			<< "\t\t\tL=sqrt((R+h)*(R+h)-R*R)." << endl;

		//Ввод входных данных
		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;


		// Решение задачи
		R = 6350;
		cout << "\tРасстояние до линии горизонта:\n";
		cout << "\t h,km"<<"\tL,km\t\tграфическое отображение величины L"<< endl;
		for (h = 1; h <= 10; h++) {
			L = sqrt(pow((R + h), 2) - R * R);
			cout << "\t" << setw(5) << setprecision(2) << fixed << h <<"\t" << L << "\t|";
			for (int i = 0; i < (L/10); i++, cout << "*");
			cout << "|\n";
		}
		//Вывод результатов программы
		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

		Sleep(3000);

		cout << "                                                                         " << endl
			<< "                                        *                                " << endl
			<< "                                        *                                " << endl
			<< "                              __________*                                " << endl
			<< "                              h2     ___*                                " << endl
			<< "                                     h1                                  " << endl
			<< "                                    000000000                            " << endl
			<< "                            0000000000000000000000000                    " << endl
			<< "                     00000000                       00000000             " << endl
			<< "                 000000                                   000000         " << endl
			<< "            00000000                E A R T H                0000000     " << endl
			<< "        0000000____________R____________|                        0000000 " << endl;

		cout << endl << endl;
		for (int i = 1; i < 100; i++, cout << "*");
		cout << endl << endl << endl;

#pragma region Pause
		cout << "\tПауза 5 секунд." << "      \r";
		Sleep(1000);
		for (int i = 5; i > 0; i--, Sleep(1000), cout << "\tОсталось ..." << i << "      \r");
		cout << "                                          ";
#pragma endregion

#pragma region keyRepeat
		int key;
		cout << "\r\tДля повтора нажмите 'Y' или 'y'...";
		key = _getch();
		if (key == 0 || key == 224) key = _getch();

		switch (key) {
		case 205:
		case 237:
		case 'Н':
		case 'н':
		case 'Y':
		case 'y': key = 0;  break;
		default: key = 1;  break;
		}

		if (key == 1) break;
#pragma endregion

	}
#pragma endregion
	//**************************************************************************

	cout << "\n\n\n\n";
	WINSETCONSOL_GARY_ON_BLACK;
	WINCLEAR;

	return 0;
}

