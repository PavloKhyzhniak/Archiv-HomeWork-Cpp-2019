extern HANDLE hStdout;
extern CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
extern WORD wOldColorAttrs;

void init() {

	//**************************************************************************
	// ��� ����������� ������ �� ������� �����
	SetConsoleOutputCP(CODE_PAGE);
	// ��� ����������� ����� �� ������� �����
	SetConsoleCP(CODE_PAGE);

	//**************************************************************************

	// Get handles to STDIN and STDOUT. 

	hStdout = GetStdHandle(STD_OUTPUT_HANDLE);

	// Save the current text colors. 

	GetConsoleScreenBufferInfo(hStdout, &csbiInfo);

	wOldColorAttrs = csbiInfo.wAttributes;

	// Set the text attributes to draw red text on black background. 

	SetConsoleTextAttribute(hStdout, FOREGROUND_RED | FOREGROUND_INTENSITY);

	//**************************************************************************

}


void Line(int x, char y) {
	cout << endl << endl << setfill(y) << setw(x) << " " << setfill(' ') << endl << endl << endl;
}

void display(int N, int A[]) {
	int cnt = 0;
	for (int i = 0; i < N; i++) {
		cout << setw(4) << A[i] << " ";
		cnt++;
		if (cnt % 10 == 0) cout << endl;
	}
	cout << endl;
}

void genArray(int N, int A[]) {
	srand(GetTickCount64());
	for (int i = 0; i < N; i++)
		A[i] = 50 + rand() % 151;
}

int MinFunc(int N, int A[]) {
	int min = A[0];
	for (int i = 0; i < N; i++)
		min = ((A[i] < min) ? A[i] : min);
	return min;
}

int MaxFunc(int N, int A[]) {
	int max = A[0];
	for (int i = 0; i < N; i++)
		max = ((A[i] > max) ? A[i] : max);
	return max;
}

