﻿
#include "pch.h"
#include "Func.cpp"
#include "Func.h"

HANDLE hStdout;
CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
WORD wOldColorAttrs;


int main()
{
	init();

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - на 25.08.2019год.");


#pragma region Part01

	while (true)
	{
		WINCLEAR;
		//Постановка решаемой задачи
		Line(100, '*');

		cout << "\t\tЗадача 01. В целочисленном массиве хранится информация о росте 25 человек(в сантиметрах).\
\n\tОпределить, на сколько рост самого высокого человека превышает рост самого низкого. Не использовать функции.\
" << endl
;

		//Ввод входных данных
		Line(100, '*');

		const int N = 25;
		int A[N] = { 0 };

		cout << endl << "Исходный массив размерностью N = " << N << " : " << endl;
		//genArray(N, A);
		srand(GetTickCount64());
		for (int i = 0; i < N; i++)
			A[i] = 50 + rand() % 151;
		
		//display(N, A);
		for (auto i : A) cout << setw(3) << i << " ";
		cout << endl;

		//int min = MinFunc(N,A);
		int min = A[0];
		for (auto i : A) min = i < min ? i : min;

		//int max = MaxFunc(N,A);
		int max = A[0];
		for (auto i : A) max = i > max ? i : max;

		cout << endl << "Рост самого высокого человека ( " << max << " см.) превышает рост самого низкого ( " << min 
			<< " см.) на " << max-min << " см." << endl;

		Line(100, '*');


		cout << endl << "Исходный массив размерностью N = " << N << " : " << endl;
		genArray(N, A);
		display(N, A);
		min = MinFunc(N,A);
		max = MaxFunc(N,A);
		
		cout << endl << "Рост самого высокого человека ( " << max << " см.) превышает рост самого низкого ( " << min
			<< " см.) на " << max - min << " см." << endl;


		Line(100, '*');

		_getch();
		break;

	}
#pragma endregion
	//**************************************************************************

	// Restore the original text colors. 
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);

	WINCLEAR;
	return 0;
}

