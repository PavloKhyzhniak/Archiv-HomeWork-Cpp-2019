

void init();
void Line(int, char);
void display(int, int[]);
void genArray(int, int[]);
int MinFunc(int, int[]);
int MaxFunc(int, int[]);

