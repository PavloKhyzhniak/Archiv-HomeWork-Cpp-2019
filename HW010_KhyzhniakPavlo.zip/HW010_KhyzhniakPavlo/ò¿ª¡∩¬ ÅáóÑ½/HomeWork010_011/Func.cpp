

void init();
void Line(int, char);
void display(int, int, int[]);
void genArray(int N, int M, int A[]);
int MinFunc(int,int, int[],int);
int MaxFunc(int,int, int[],int);
void displayMin(int, int, int[], int, int);
void displayMax(int, int, int[], int, int);

