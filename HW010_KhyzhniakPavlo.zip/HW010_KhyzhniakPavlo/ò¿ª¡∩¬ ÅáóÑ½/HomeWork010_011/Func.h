extern HANDLE hStdout;
extern CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
extern WORD wOldColorAttrs;

void init() {

	//**************************************************************************
	// ��� ����������� ������ �� ������� �����
	SetConsoleOutputCP(CODE_PAGE);
	// ��� ����������� ����� �� ������� �����
	SetConsoleCP(CODE_PAGE);

	//**************************************************************************

	// Get handles to STDIN and STDOUT. 

	hStdout = GetStdHandle(STD_OUTPUT_HANDLE);

	// Save the current text colors. 

	GetConsoleScreenBufferInfo(hStdout, &csbiInfo);

	wOldColorAttrs = csbiInfo.wAttributes;

	// Set the text attributes to draw red text on black background. 

	SetConsoleTextAttribute(hStdout, FOREGROUND_RED | FOREGROUND_INTENSITY);

	//**************************************************************************

}


void Line(int x, char y) {
	cout << endl << endl << setfill(y) << setw(x) << " " << setfill(' ') << endl << endl << endl;
}

void display(int N, int M, int A[]) {
	int cnt = 0;
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			cout << setw(3) << A[i * M + j] << " ";
		}
		cout << endl;
	}
	cout << endl;
}

void genArray(int N, int M, int A[]) {
	srand(GetTickCount64()); 
	for (int i = 0; i < N; i++)
		for (int j = 0; j < M; j++)
			A[i*M+j] = -100 + rand() % 201;
}

int MinFunc(int N,int M, int A[],int row) {
	int min = A[row*M];
	for (int i = row; i <= row; i++)
		for (int j = 0; j < M; j++)
			min = A[i * M + j] < min ? A[i * M + j] : min;
	return min;
}

void displayMin(int N, int M, int A[], int row, int min) {
	cout << "\n������� �������� " << min << " � ���� " << row+1 << ".\n";
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			if ((i == row) && (A[i * M + j] == min)) SetConsoleTextAttribute(hStdout, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
			cout << setw(3) << A[i * M + j] << " ";
			SetConsoleTextAttribute(hStdout, FOREGROUND_RED | FOREGROUND_INTENSITY);
		}
		cout << endl;
	}
	cout << endl;
}

int MaxFunc(int N,int M, int A[],int col) {
	int max = A[col];
	for (int i = 0; i < N; i++)
		for (int j = col; j <= col; j++)
			max = A[i * M + j] > max ? A[i * M + j] : max;
	return max;
}

void displayMax(int N, int M, int A[], int col, int max){
	cout << "\n������� �������� " << max << " � ������� " << col+1 << ".\n";
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			if ((j == col) && (A[i * M + j] == max)) SetConsoleTextAttribute(hStdout, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
			cout << setw(3) << A[i * M + j] << " ";
			SetConsoleTextAttribute(hStdout, FOREGROUND_RED | FOREGROUND_INTENSITY);
		}
		cout << endl;
	}
	cout << endl;
}

