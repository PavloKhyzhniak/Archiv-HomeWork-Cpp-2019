﻿
#include "pch.h"
#include "Func.cpp"
#include "Func.h"

HANDLE hStdout;
CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
WORD wOldColorAttrs;


int main()
{
	init();

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - на 25.08.2019год.");


#pragma region Part01

	while (true)
	{
		WINCLEAR;
		//Постановка решаемой задачи
		Line(100, '*');

		cout << "\t\tЗадача 02. Не использовать функции. Для двумерного массива случайных целых чисел\
\n\t(размерность массива 8 строк на 7 столбцов) найти:\
\n\t- минимальное значение среди элементов заданной строки,вывести матрицу\
\n\tс выделением цветом минимальных значений в заданной строке;\
\n\t- максимальное значение среди элементов заданного столбца,\
\n\tвывести матрицу с выделением цветом максимальных значений в заданном столбце.\
" << endl
;

		//Ввод входных данных
		Line(100, '*');

		const int N = 8, M = 7;
		int A[N][M] = { 0 };

		cout << endl << "Исходный массив размерностью N x M = " << N << " x " << M << " : " << endl;
		//genArray(N, M, reinterpret_cast<int*>(A));
		srand(GetTickCount64());
		for (int i = 0; i < N; i++)
			for (int j = 0; j < M; j++)
				A[i][j] = -100 + rand() % 201;

		//display(N, M, reinterpret_cast<int*>(A));
		int cnt = 0;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++)
				cout << setw(3) << A[i][j] << " ";
			cout << endl;
		}
		
		cout << endl;

		//int min = MinFunc(N, M, reinterpret_cast<int*>(A), row);
		int row = 0;
		cout << endl << "Введите искомый ряд: ";
		while (row < 1) cin >> row;
		row--;

		int min = A[row][0];
		for (int i = row; i <= row; i++)
			for (int j = 0; j < M; j++)
				min = A[i][j] < min ? A[i][j] : min;

		//displayMin(N, M, reinterpret_cast<int*>(A), row, min);
		cout << endl << "Минимальное значение в строке " << row + 1 << " : " << endl;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				if ((i==row)&&(A[i][j]==min)) SetConsoleTextAttribute(hStdout, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
				cout << setw(3) << A[i][j] << " ";
				SetConsoleTextAttribute(hStdout, FOREGROUND_RED | FOREGROUND_INTENSITY);
			}
			cout << endl;
		}

		//int max = MaxFunc(N, M, reinterpret_cast<int*>(A), col);
		int col = 0;
		cout << endl << "Введите искомый столбец: ";
		while(col<1) cin >> col;
		col--;
		
		int max = A[0][col];
		for (int i = 0; i < N; i++)
			for (int j = col; j <= col; j++)
				max = A[i][j] > max ? A[i][j] : max;

		//displayMax(N, M, reinterpret_cast<int*>(A), col, max);
		cout << endl << "Максимальное значение в столбце "<< col+1 << " : " << endl;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				if ((j == col) && (A[i][j] == max)) SetConsoleTextAttribute(hStdout, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
				cout << setw(3) << A[i][j] << " ";
				SetConsoleTextAttribute(hStdout, FOREGROUND_RED | FOREGROUND_INTENSITY);
			}
			cout << endl;
		}


		Line(100, '*');

		cout << endl << "Исходный массив размерностью N x M = " << N << " x " << M << " : " << endl;
		genArray(N, M, reinterpret_cast<int*>(A));
		display(N, M, reinterpret_cast<int*>(A));
		
		min = MinFunc(N, M, reinterpret_cast<int*>(A), row);
		displayMin(N, M, reinterpret_cast<int*>(A), row, min);
		
		max = MaxFunc(N, M, reinterpret_cast<int*>(A), col);
		displayMax(N, M, reinterpret_cast<int*>(A), col, max);
		

		Line(100, '*');

		_getch();
		break;

	}
#pragma endregion
	//**************************************************************************

	// Restore the original text colors. 
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);

	WINCLEAR;
	return 0;
}

