﻿
#include "pch.h"
#include "Func.cpp"
#include "Func.h"

HANDLE hStdout;
CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
WORD wOldColorAttrs;


int main()
{
	init();

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - на 25.08.2019год.");


#pragma region Part01

	while (true)
	{
		WINCLEAR;
		//Постановка решаемой задачи
		Line(100, '*');

		cout << "\t\tЗадача 04. Описать функцию RootsCount(A,B,C) целого типа,\
\n\tопределяющую количество корней квадратного уравнения A*X^2+B*X+C=0,\
\n\t(A,B,C - вещественные параметры, A!=0). С ее помощью найти количество\
\n\tкорней для каждого из трех квадратных уравнений с данными коэффициентами.\
\n\tКоличество корней определять по значению дискриминанта: D = B^2-4*A*C.\
" << endl
;

		//Ввод входных данных
		Line(100, '*');

		srand(GetTickCount64());
		
		double A, B, C;
		
		for (int i = 0; i < 3; i++) {
			cout << endl << "Уравнение № " << (i+1) << endl;
			A = 0;
			while (A == 0) A = -50 + rand() % 101;
			B = -50 + rand() % 101;
			C = -50 + rand() % 101;
			cout << setprecision(2) << fixed
				<< A << " * X * X "<< ((B>=0)?"+ ":"") << B << " * X " << ((C >= 0) ? "+ " : "") << C << " = 0;" << endl;
			switch (RootsCount(A, B, C)) {
			case 2:
				cout << endl << "Уравнение содержит 2 корня" << endl;
				break;
			case 1:
				cout << endl << "Уравнение содержит 1 корень(два одинаковых корня)" << endl;
				break;
			case 0:
				cout << endl << "Уравнение не содержит действительных корней" << endl;
				break;
			default:
				cout << endl << "Упсс..Что-то пошло не так(((" << endl;
				break;
			}
		}

		Line(100, '*');

		_getch();
		break;

	}
#pragma endregion
	//**************************************************************************

	// Restore the original text colors. 
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);

	WINCLEAR;
	return 0;
}

