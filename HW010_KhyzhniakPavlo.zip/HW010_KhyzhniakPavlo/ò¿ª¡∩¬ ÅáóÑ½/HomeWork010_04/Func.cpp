

void init();
void Line(int, char);

int RootsCount(double, double, double);
