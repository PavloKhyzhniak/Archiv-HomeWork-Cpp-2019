

void init();
void Line(int, char);
void display(int, int, int[]);
void genArray(int , int , int []);
void swapRow(int , int , int [],int ,int);
void swapCol(int, int, int[], int, int);
void newIndex(int*, int*, int);
