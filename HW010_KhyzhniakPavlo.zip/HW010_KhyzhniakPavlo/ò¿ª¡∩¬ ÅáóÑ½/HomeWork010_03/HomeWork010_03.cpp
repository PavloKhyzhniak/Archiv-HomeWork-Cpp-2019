﻿
#include "pch.h"
#include "Func.cpp"
#include "Func.h"

HANDLE hStdout;
CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
WORD wOldColorAttrs;


int main()
{
	init();

	// Установим актуальный заголовок окна
	SetConsoleTitle(L"Домашняя работа - на 25.08.2019год.");


#pragma region Part01

	while (true)
	{
		WINCLEAR;
		//Постановка решаемой задачи
		Line(100, '*');

		cout << "\t\tЗадача 03. Не использовать функции. Для двумерного массива случайных\
\n\tвещественных чисел(размерность массива 5 строк на 6 столбцов) выполнить:\
\n\t- перестановку двух любых строк;\
\n\t- перестановку двух любых столбцов.\
" << endl
;

		//Ввод входных данных
		Line(100, '*');

		const int N = 5, M = 6;
		int A[N][M] = { 0 };

		cout << endl << "Исходный массив размерностью N x M = " << N << " x " << M << " : " << endl;
		//genArray(N, M, reinterpret_cast<int*>(A));
		srand(GetTickCount64());
		for (int i = 0; i < N; i++)
			for (int j = 0; j < M; j++)
				A[i][j] = -100 + rand() % 201;

		//display(N, M, reinterpret_cast<int*>(A));
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++)
				cout << setw(3) << A[i][j] << " ";
			cout << endl;
		}
		cout << endl;

		//newIndex(&row1, &row2, N);
		int row1 = rand()%N;
		int row2 = row1;
		while(row1==row2) row2 = rand() % N;

		//swapRow(N, M, reinterpret_cast<int*>(A), row1, row2);
		cout << endl << "Переставим элементы строк под индексами: " << row1 << " и " << row2 << "." << endl;
		for (int j = 0; j < M; j++)
			swap(A[row1][j],A[row2][j]);

		//display(N, M, reinterpret_cast<int*>(A));
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++)
				cout << setw(3) << A[i][j] << " ";
			cout << endl;
		}
		cout << endl;

		//newIndex(&col1, &col2, M);
		int col1 = rand()%M;
		int col2 = col1;
		while(col1==col2) col2 = rand() % M;

		//swapCol(N, M, reinterpret_cast<int*>(A), col1, col2);
		cout << endl << "Переставим элементы столбцов под индексами: " << col1 << " и " << col2 << "."<< endl;
		for (int i = 0; i < N; i++)
			swap(A[i][col1],A[i][col2]);

		//display(N, M, reinterpret_cast<int*>(A));
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++)
				cout << setw(3) << A[i][j] << " ";
			cout << endl;
		}
		cout << endl;


		Line(100, '*');

		cout << endl << "Исходный массив размерностью N x M = " << N << " x " << M << " : " << endl;
		genArray(N, M, reinterpret_cast<int*>(A));
		display(N, M, reinterpret_cast<int*>(A));
		
		newIndex(&row1, &row2, N);
		swapRow(N, M, reinterpret_cast<int*>(A), row1, row2);
		display(N, M, reinterpret_cast<int*>(A));
		
		newIndex(&col1, &col2, M);
		swapCol(N, M, reinterpret_cast<int*>(A), col1, col2);
		display(N, M, reinterpret_cast<int*>(A));


		Line(100, '*');

		_getch();
		break;

	}
#pragma endregion
	//**************************************************************************

	// Restore the original text colors. 
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);

	WINCLEAR;
	return 0;
}

